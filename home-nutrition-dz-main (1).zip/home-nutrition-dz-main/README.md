# Nourish Algeria

Build a production-ready full-stack e-commerce web application for an online food-supplement store operating exclusively in Algeria.



This is NOT a landing page and NOT a static prototype.



I need a real working application with a proper database, authentication, CRUD operations, cart, checkout, orders, reviews, inventory, packs, and an admin dashboard.



1. TECH STACK



Use a modern production-ready stack supported by Lovable.



Use:



- React

- TypeScript

- Tailwind CSS

- Supabase for database/authentication/storage where appropriate

- Proper relational database structure

- Secure authentication and authorization



Do not hardcode product data when it should come from the database.



2. DATABASE



Create appropriate tables/entities for:



- products

- categories

- packs

- pack_items

- inventory

- customers

- orders

- order_items

- reviews

- ratings

- admin users



Use proper relationships and validation.



3. CUSTOMER STORE



Create:



Home

Shop

Categories

Product Details

Packs

Cart

Checkout

Order Confirmation

Order Tracking

Reviews



Products must load dynamically from the database.



4. CART



Implement a real cart.



Users can:



- Add products

- Remove products

- Change quantities

- Add packs

- See subtotal

- See delivery cost

- See final total



Validate stock before allowing checkout.



5. CHECKOUT — ALGERIA ONLY



This store ONLY sells and delivers inside Algeria.



Do not provide international checkout.



Collect:



- Full name

- Algerian phone number

- Wilaya

- Commune/region

- Delivery address

- Delivery method



Delivery methods:



Home delivery

Desk/Bureau delivery



Use Algerian Wilayas in the Wilaya selector.



Currency:

DZD / DA



Validate Algerian phone numbers and required address fields.



6. ORDERS



When checkout is submitted, create a real order in the database.



Generate a unique order number.



Store:



- Customer

- Phone

- Wilaya

- Commune

- Address

- Delivery method

- Products

- Quantities

- Prices

- Delivery fee

- Total

- Date

- Status



Statuses:



New

Confirmed

Preparing

Shipped

Delivered

Cancelled



7. ADMIN DASHBOARD



Create protected admin routes.



Only authenticated administrators can access them.



Dashboard sections:



Overview

Products

Categories

Packs

Inventory

Orders

Customers

Reviews



Admins can:



ADD / EDIT / DELETE PRODUCTS



Each product:



- Name

- Description

- Price

- Discount

- Images

- Category

- Stock

- Featured status

- Availability



8. PACK BUILDER



Admins can create a pack by selecting existing products.



Pack:



- Name

- Description

- Image

- Products

- Quantity of each product

- Original combined price

- Pack price

- Discount

- Stock/availability



Customers can purchase the pack as a single cart item.



9. REVIEWS



Implement a 1–5 star rating system.



Customers can submit reviews.



Display:



- Average rating

- Rating distribution

- Review count

- Reviews



Allow admins to moderate/delete reviews.



10. SEARCH / FILTERS



Implement real search.



Search by product name.



Filters:



- Category

- Price

- Rating

- Availability

- Featured

- Packs



11. THREE LANGUAGES



The application must support:



Arabic

French

English



Implement proper internationalization.



Arabic:



- RTL

- Arabic translations

- Correct alignment



French/English:



- LTR



The language selector should persist the user's choice.



12. DESIGN



Create a premium modern supplement-store aesthetic.



Style:



- Clean

- Athletic

- Premium

- Minimal

- Modern

- Trustworthy



Use a dark/white foundation with one strong accent color.



Use:



- Large product photography

- Strong typography

- Rounded product cards

- Subtle animations

- Modern navigation

- Clean checkout

- Excellent mobile UX



Do not make it look like a generic SaaS dashboard.



The customer-facing store should look like a professional supplement e-commerce website.



13. MOBILE FIRST



Optimize primarily for smartphones.



The store must work properly on:



- Android

- iPhone

- Tablet

- Desktop



Use:



- Mobile navigation

- Sticky cart access

- Touch-friendly buttons

- Responsive product grids

- Easy checkout



14. SECURITY



Protect admin routes.



Never expose admin functionality to normal customers.



Validate all user inputs.



Use secure authentication and database permissions.



15. IMPORTANT



Do not create fake functionality.



Buttons must perform real actions.



Products must come from the database.



Orders must be stored in the database.



Admin changes must update the customer storefront.



Reviews must be stored.



Inventory must update when orders are processed.



The final application must be a genuinely functional Algerian e-commerce store, not a visual mockup.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://home-nutrition-dz.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/640b09a8-ed4c-4a1d-afca-a7ec24487605).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
