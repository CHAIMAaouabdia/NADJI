
-- ROLES
CREATE TYPE public.app_role AS ENUM ('admin','customer');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- PROFILES
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  phone text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile" ON public.profiles FOR ALL TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE TRIGGER profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'phone')
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'customer') ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- CATEGORIES
CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_en text NOT NULL,
  name_fr text NOT NULL,
  name_ar text NOT NULL,
  image_url text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.categories TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories public read" ON public.categories FOR SELECT USING (true);
CREATE POLICY "categories admin write" ON public.categories FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- PRODUCTS
CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_en text NOT NULL,
  name_fr text NOT NULL,
  name_ar text NOT NULL,
  description_en text DEFAULT '',
  description_fr text DEFAULT '',
  description_ar text DEFAULT '',
  brand text,
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  discount_percent int NOT NULL DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent < 100),
  images text[] NOT NULL DEFAULT '{}',
  category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL,
  stock int NOT NULL DEFAULT 0 CHECK (stock >= 0),
  featured boolean NOT NULL DEFAULT false,
  is_available boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.products TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products public read" ON public.products FOR SELECT USING (true);
CREATE POLICY "products admin write" ON public.products FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER products_updated BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- PACKS
CREATE TABLE public.packs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_en text NOT NULL,
  name_fr text NOT NULL,
  name_ar text NOT NULL,
  description_en text DEFAULT '',
  description_fr text DEFAULT '',
  description_ar text DEFAULT '',
  image_url text,
  pack_price numeric(10,2) NOT NULL CHECK (pack_price >= 0),
  stock int NOT NULL DEFAULT 0 CHECK (stock >= 0),
  featured boolean NOT NULL DEFAULT false,
  is_available boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.packs TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.packs TO authenticated;
GRANT ALL ON public.packs TO service_role;
ALTER TABLE public.packs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "packs public read" ON public.packs FOR SELECT USING (true);
CREATE POLICY "packs admin write" ON public.packs FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER packs_updated BEFORE UPDATE ON public.packs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.pack_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pack_id uuid NOT NULL REFERENCES public.packs(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  quantity int NOT NULL DEFAULT 1 CHECK (quantity > 0),
  UNIQUE (pack_id, product_id)
);
GRANT SELECT ON public.pack_items TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.pack_items TO authenticated;
GRANT ALL ON public.pack_items TO service_role;
ALTER TABLE public.pack_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pack_items public read" ON public.pack_items FOR SELECT USING (true);
CREATE POLICY "pack_items admin write" ON public.pack_items FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- ORDERS
CREATE TYPE public.order_status AS ENUM ('new','confirmed','preparing','shipped','delivered','cancelled');
CREATE TYPE public.delivery_method AS ENUM ('home','desk');

CREATE SEQUENCE public.order_number_seq START 1000;

CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text NOT NULL UNIQUE DEFAULT ('DZ-' || to_char(now(),'YYMM') || '-' || nextval('public.order_number_seq')),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name text NOT NULL,
  phone text NOT NULL,
  wilaya text NOT NULL,
  commune text NOT NULL,
  address text NOT NULL,
  delivery_method public.delivery_method NOT NULL DEFAULT 'home',
  notes text,
  subtotal numeric(10,2) NOT NULL,
  delivery_fee numeric(10,2) NOT NULL,
  total numeric(10,2) NOT NULL,
  status public.order_status NOT NULL DEFAULT 'new',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "orders own read" ON public.orders FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "orders admin update" ON public.orders FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER orders_updated BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  pack_id uuid REFERENCES public.packs(id) ON DELETE SET NULL,
  item_name text NOT NULL,
  unit_price numeric(10,2) NOT NULL,
  quantity int NOT NULL CHECK (quantity > 0),
  line_total numeric(10,2) NOT NULL
);
GRANT SELECT ON public.order_items TO authenticated;
GRANT ALL ON public.order_items TO service_role;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "order_items own read" ON public.order_items FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND (o.user_id = auth.uid() OR public.has_role(auth.uid(),'admin')))
);

-- REVIEWS
CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name text NOT NULL DEFAULT 'Customer',
  rating int NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment text,
  is_approved boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.reviews TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reviews public read" ON public.reviews FOR SELECT USING (is_approved = true);
CREATE POLICY "reviews own read" ON public.reviews FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "reviews insert own" ON public.reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "reviews delete own" ON public.reviews FOR DELETE TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "reviews admin update" ON public.reviews FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- SEED
INSERT INTO public.categories (slug, name_en, name_fr, name_ar, sort_order, image_url) VALUES
('protein','Protein','Protéines','بروتين',1,'/images/cat-protein.jpg'),
('mass-gainers','Mass Gainers','Prise de masse','زيادة الوزن',2,'/images/cat-gainer.jpg'),
('pre-workout','Pre-Workout','Pré-entraînement','قبل التمرين',3,'/images/cat-preworkout.jpg'),
('vitamins','Vitamins & Health','Vitamines & Santé','فيتامينات وصحة',4,'/images/cat-vitamins.jpg');

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'whey-isolate-2kg','Whey Isolate 2kg','Whey Isolate 2kg','واي أيزوليت 2 كغ',
'Ultra-filtered whey protein isolate, 27g protein per scoop, low lactose.',
'Isolat de protéine de lactosérum ultra-filtré, 27g de protéines par dose.',
'بروتين واي أيزوليت مرشح للغاية، 27 غرام بروتين لكل حصة.',
'NutriDZ',12500,10,ARRAY['/images/product-whey.jpg'],c.id,40,true FROM public.categories c WHERE c.slug='protein';

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'whey-concentrate-1kg','Whey Concentrate 1kg','Whey Concentrate 1kg','واي كونسنتريت 1 كغ',
'Classic whey concentrate for daily protein support and recovery.',
'Concentré de whey classique pour la récupération quotidienne.',
'واي كونسنتريت كلاسيكي لدعم البروتين اليومي والاستشفاء.',
'NutriDZ',6900,0,ARRAY['/images/product-whey.jpg'],c.id,60,false FROM public.categories c WHERE c.slug='protein';

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'mass-gainer-3kg','Mass Gainer 3kg','Gainer de masse 3kg','مكمل زيادة الوزن 3 كغ',
'High-calorie blend with complex carbs and protein for clean weight gain.',
'Mélange riche en calories avec glucides complexes et protéines.',
'خلطة عالية السعرات مع كربوهيدرات معقدة وبروتين.',
'NutriDZ',9800,5,ARRAY['/images/product-gainer.jpg'],c.id,25,true FROM public.categories c WHERE c.slug='mass-gainers';

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'pre-workout-300g','Pre-Workout Ignite 300g','Pré-Workout Ignite 300g','قبل التمرين إغنايت 300غ',
'Caffeine, beta-alanine and citrulline for explosive training energy.',
'Caféine, bêta-alanine et citrulline pour une énergie explosive.',
'كافيين وبيتا ألانين وسيترولين لطاقة تدريب انفجارية.',
'NutriDZ',4500,0,ARRAY['/images/product-preworkout.jpg'],c.id,50,true FROM public.categories c WHERE c.slug='pre-workout';

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'creatine-500g','Creatine Monohydrate 500g','Créatine Monohydrate 500g','كرياتين مونوهيدرات 500غ',
'Micronized creatine monohydrate for strength and power output.',
'Créatine monohydrate micronisée pour la force et la puissance.',
'كرياتين مونوهيدرات مطحون لزيادة القوة.',
'NutriDZ',3900,0,ARRAY['/images/product-creatine.jpg'],c.id,80,true FROM public.categories c WHERE c.slug='pre-workout';

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'omega-3-120','Omega 3 Fish Oil 120 caps','Omega 3 Huile de poisson 120 caps','أوميغا 3 زيت السمك 120 كبسولة',
'High-purity EPA/DHA capsules for heart and joint health.',
'Capsules EPA/DHA de haute pureté pour le cœur et les articulations.',
'كبسولات عالية النقاء لصحة القلب والمفاصل.',
'NutriDZ',2600,0,ARRAY['/images/product-vitamins.jpg'],c.id,70,false FROM public.categories c WHERE c.slug='vitamins';

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'multivitamin-90','Daily Multivitamin 90 tabs','Multivitamines 90 comprimés','مالتي فيتامين 90 قرص',
'Complete daily vitamin and mineral complex for active people.',
'Complexe complet de vitamines et minéraux pour les sportifs.',
'مجموعة كاملة من الفيتامينات والمعادن اليومية.',
'NutriDZ',2200,0,ARRAY['/images/product-vitamins.jpg'],c.id,90,false FROM public.categories c WHERE c.slug='vitamins';

INSERT INTO public.products (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,brand,price,discount_percent,images,category_id,stock,featured)
SELECT 'bcaa-400g','BCAA 2:1:1 400g','BCAA 2:1:1 400g','بي سي إي إي 400غ',
'Intra-workout amino acids to reduce fatigue and protect muscle.',
'Acides aminés intra-entraînement pour réduire la fatigue.',
'أحماض أمينية أثناء التمرين لتقليل التعب.',
'NutriDZ',3400,15,ARRAY['/images/product-creatine.jpg'],c.id,0,false FROM public.categories c WHERE c.slug='pre-workout';

INSERT INTO public.packs (slug,name_en,name_fr,name_ar,description_en,description_fr,description_ar,image_url,pack_price,stock,featured)
VALUES
('mass-pack','Mass Builder Pack','Pack Prise de Masse','باك زيادة الكتلة',
'Mass gainer + creatine, everything you need to grow.',
'Gainer + créatine, tout pour prendre de la masse.',
'مكمل زيادة الوزن + كرياتين، كل ما تحتاجه للنمو.',
'/images/pack-mass.jpg',12900,15,true),
('performance-pack','Performance Pack','Pack Performance','باك الأداء',
'Whey isolate + pre-workout for peak training performance.',
'Whey isolate + pré-workout pour une performance maximale.',
'واي أيزوليت + قبل التمرين لأفضل أداء.',
'/images/pack-performance.jpg',15900,10,true);

INSERT INTO public.pack_items (pack_id, product_id, quantity)
SELECT p.id, pr.id, 1 FROM public.packs p, public.products pr WHERE p.slug='mass-pack' AND pr.slug IN ('mass-gainer-3kg','creatine-500g');
INSERT INTO public.pack_items (pack_id, product_id, quantity)
SELECT p.id, pr.id, 1 FROM public.packs p, public.products pr WHERE p.slug='performance-pack' AND pr.slug IN ('whey-isolate-2kg','pre-workout-300g');
