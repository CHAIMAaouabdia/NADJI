REVOKE EXECUTE ON FUNCTION public.is_owner(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.is_staff(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;
REVOKE EXECUTE ON FUNCTION public.enforce_admin_limit() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM anon, authenticated;

INSERT INTO public.user_roles (user_id, role)
SELECT id, 'owner'::public.app_role FROM auth.users WHERE email = 'abidnadji580@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

INSERT INTO public.admin_accounts (user_id, full_name, email, is_active)
SELECT u.id, coalesce(p.full_name, 'Owner'), u.email, true
FROM auth.users u LEFT JOIN public.profiles p ON p.id = u.id
WHERE u.email = 'abidnadji580@gmail.com'
ON CONFLICT (user_id) DO UPDATE SET is_active = true;