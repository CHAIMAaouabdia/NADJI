DROP POLICY IF EXISTS "reviews public read" ON public.reviews;
REVOKE SELECT ON public.reviews FROM anon;

CREATE OR REPLACE VIEW public.reviews_public AS
SELECT id, product_id, rating, comment, author_name, created_at
FROM public.reviews
WHERE is_approved = true;

GRANT SELECT ON public.reviews_public TO anon, authenticated;