-- 1. owner role value (used only via text comparison in this migration)
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'owner';

-- 2. admin accounts
CREATE TABLE public.admin_accounts (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  email text NOT NULL,
  phone text,
  is_active boolean NOT NULL DEFAULT true,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.admin_accounts TO authenticated;
GRANT ALL ON public.admin_accounts TO service_role;
ALTER TABLE public.admin_accounts ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER admin_accounts_updated BEFORE UPDATE ON public.admin_accounts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3. role helpers
CREATE OR REPLACE FUNCTION public.is_owner(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role::text = 'owner'
  )
$$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = _user_id
      AND (
        ur.role::text = 'owner'
        OR (
          ur.role::text = 'admin'
          AND EXISTS (
            SELECT 1 FROM public.admin_accounts a
            WHERE a.user_id = _user_id AND a.is_active
          )
        )
      )
  )
$$;

-- 4. max 3 active admin accounts
CREATE OR REPLACE FUNCTION public.enforce_admin_limit()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE active_count int;
BEGIN
  IF NEW.is_active THEN
    SELECT count(*) INTO active_count
    FROM public.admin_accounts
    WHERE is_active AND user_id <> NEW.user_id;
    IF active_count >= 3 THEN
      RAISE EXCEPTION 'admin_limit_reached';
    END IF;
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER admin_accounts_limit BEFORE INSERT OR UPDATE ON public.admin_accounts
FOR EACH ROW EXECUTE FUNCTION public.enforce_admin_limit();

CREATE POLICY "admin_accounts staff read" ON public.admin_accounts
FOR SELECT TO authenticated USING (public.is_staff(auth.uid()) OR auth.uid() = user_id);
CREATE POLICY "admin_accounts owner write" ON public.admin_accounts
FOR ALL TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));

-- 5. store settings (single row)
CREATE TABLE public.store_settings (
  id boolean PRIMARY KEY DEFAULT true,
  store_name text NOT NULL DEFAULT 'Home Nutrition',
  logo_url text,
  whatsapp text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  facebook text NOT NULL DEFAULT '',
  instagram text NOT NULL DEFAULT '',
  tiktok text NOT NULL DEFAULT '',
  extra_links jsonb NOT NULL DEFAULT '[]'::jsonb,
  footer_text text NOT NULL DEFAULT '',
  delivery_info text NOT NULL DEFAULT '',
  free_delivery_threshold integer NOT NULL DEFAULT 20000,
  home_delivery_enabled boolean NOT NULL DEFAULT true,
  desk_delivery_enabled boolean NOT NULL DEFAULT true,
  delivery_prices jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT store_settings_singleton CHECK (id)
);
GRANT SELECT ON public.store_settings TO anon;
GRANT SELECT, INSERT, UPDATE ON public.store_settings TO authenticated;
GRANT ALL ON public.store_settings TO service_role;
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "store_settings public read" ON public.store_settings
FOR SELECT USING (true);
CREATE POLICY "store_settings owner write" ON public.store_settings
FOR ALL TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));

CREATE TRIGGER store_settings_updated BEFORE UPDATE ON public.store_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.store_settings (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

-- 6. order archiving + staff management
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS archived boolean NOT NULL DEFAULT false;

DROP POLICY IF EXISTS "orders admin update" ON public.orders;
DROP POLICY IF EXISTS "orders own read" ON public.orders;
CREATE POLICY "orders read" ON public.orders
FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.is_staff(auth.uid()));
CREATE POLICY "orders staff update" ON public.orders
FOR UPDATE TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));
CREATE POLICY "orders staff delete" ON public.orders
FOR DELETE TO authenticated USING (public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "order_items own read" ON public.order_items;
CREATE POLICY "order_items read" ON public.order_items
FOR SELECT TO authenticated USING (EXISTS (
  SELECT 1 FROM public.orders o
  WHERE o.id = order_items.order_id AND (o.user_id = auth.uid() OR public.is_staff(auth.uid()))
));
CREATE POLICY "order_items staff delete" ON public.order_items
FOR DELETE TO authenticated USING (public.is_staff(auth.uid()));

-- 7. staff write access on catalogue
DROP POLICY IF EXISTS "products admin write" ON public.products;
CREATE POLICY "products staff write" ON public.products
FOR ALL TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "categories admin write" ON public.categories;
CREATE POLICY "categories staff write" ON public.categories
FOR ALL TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "packs admin write" ON public.packs;
CREATE POLICY "packs staff write" ON public.packs
FOR ALL TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "pack_items admin write" ON public.pack_items;
CREATE POLICY "pack_items staff write" ON public.pack_items
FOR ALL TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "reviews admin update" ON public.reviews;
CREATE POLICY "reviews staff update" ON public.reviews
FOR UPDATE TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));
DROP POLICY IF EXISTS "reviews delete own" ON public.reviews;
CREATE POLICY "reviews delete own or staff" ON public.reviews
FOR DELETE TO authenticated USING (auth.uid() = user_id OR public.is_staff(auth.uid()));
DROP POLICY IF EXISTS "reviews own read" ON public.reviews;
CREATE POLICY "reviews read own or staff" ON public.reviews
FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.is_staff(auth.uid()));

-- 8. staff can read customer profiles
CREATE POLICY "profiles staff read" ON public.profiles
FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));

-- 9. owner manages roles
CREATE POLICY "user_roles owner write" ON public.user_roles
FOR ALL TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));
CREATE POLICY "user_roles staff read" ON public.user_roles
FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));