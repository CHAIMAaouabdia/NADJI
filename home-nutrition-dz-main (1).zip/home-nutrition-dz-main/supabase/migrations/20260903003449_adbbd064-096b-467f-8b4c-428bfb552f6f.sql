ALTER VIEW public.reviews_public SET (security_invoker = on);

CREATE POLICY "reviews public read" ON public.reviews
FOR SELECT TO anon
USING (is_approved = true);

GRANT SELECT (id, product_id, rating, comment, author_name, created_at, is_approved) ON public.reviews TO anon;