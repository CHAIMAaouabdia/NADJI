ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS flavor text,
  ADD COLUMN IF NOT EXISTS size text;

ALTER TABLE public.packs
  ADD COLUMN IF NOT EXISTS discount_percent integer NOT NULL DEFAULT 0;

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS payment_method text NOT NULL DEFAULT 'cod';

ALTER TABLE public.orders ALTER COLUMN address DROP NOT NULL;

CREATE OR REPLACE FUNCTION public.transfer_ownership(_new_owner uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE caller uuid := auth.uid();
BEGIN
  IF caller IS NULL OR NOT public.is_owner(caller) THEN
    RAISE EXCEPTION 'only_owner_can_transfer';
  END IF;
  IF _new_owner = caller THEN
    RAISE EXCEPTION 'already_owner';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.admin_accounts WHERE user_id = _new_owner AND is_active) THEN
    RAISE EXCEPTION 'target_must_be_active_admin';
  END IF;

  -- new owner gets the owner role
  INSERT INTO public.user_roles (user_id, role) VALUES (_new_owner, 'owner')
  ON CONFLICT (user_id, role) DO NOTHING;

  -- previous owner is demoted to admin and keeps dashboard access
  DELETE FROM public.user_roles WHERE user_id = caller AND role = 'owner';
  INSERT INTO public.user_roles (user_id, role) VALUES (caller, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;

  DELETE FROM public.user_roles WHERE user_id = _new_owner AND role = 'admin';
END; $$;

REVOKE ALL ON FUNCTION public.transfer_ownership(uuid) FROM public;
GRANT EXECUTE ON FUNCTION public.transfer_ownership(uuid) TO authenticated;