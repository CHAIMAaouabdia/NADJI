-- 1. Storage RLS for product-images (RLS is already enabled on storage.objects)
DROP POLICY IF EXISTS "product_images_public_read" ON storage.objects;
CREATE POLICY "product_images_public_read"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "product_images_staff_insert" ON storage.objects;
CREATE POLICY "product_images_staff_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'product-images' AND public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "product_images_staff_update" ON storage.objects;
CREATE POLICY "product_images_staff_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'product-images' AND public.is_staff(auth.uid()))
WITH CHECK (bucket_id = 'product-images' AND public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "product_images_staff_delete" ON storage.objects;
CREATE POLICY "product_images_staff_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'product-images' AND public.is_staff(auth.uid()));

-- 2. Admin notifications
CREATE TABLE public.notifications (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  order_id uuid REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id) ON DELETE CASCADE,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX notifications_created_idx ON public.notifications (created_at DESC);

GRANT SELECT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notifications staff read" ON public.notifications
FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));

CREATE POLICY "notifications staff update" ON public.notifications
FOR UPDATE TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

CREATE POLICY "notifications staff delete" ON public.notifications
FOR DELETE TO authenticated USING (public.is_staff(auth.uid()));

-- 3. Triggers that create notifications
CREATE OR REPLACE FUNCTION public.notify_new_order()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (type, title, body, order_id)
  VALUES (
    'new_order',
    'New order ' || NEW.order_number,
    NEW.full_name || ' — ' || NEW.wilaya || ' — ' || NEW.total::text || ' DZD',
    NEW.id
  );
  RETURN NEW;
END; $$;

CREATE TRIGGER orders_notify_new
AFTER INSERT ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.notify_new_order();

CREATE OR REPLACE FUNCTION public.notify_stock_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.stock = 0 AND OLD.stock > 0 THEN
    INSERT INTO public.notifications (type, title, body, product_id)
    VALUES ('out_of_stock', 'Out of stock: ' || NEW.name_en, 'This product is now out of stock.', NEW.id);
  ELSIF NEW.stock > 0 AND NEW.stock <= 5 AND OLD.stock > 5 THEN
    INSERT INTO public.notifications (type, title, body, product_id)
    VALUES ('low_stock', 'Low stock: ' || NEW.name_en, 'Only ' || NEW.stock::text || ' left in stock.', NEW.id);
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER products_notify_stock
AFTER UPDATE OF stock ON public.products
FOR EACH ROW EXECUTE FUNCTION public.notify_stock_change();