REVOKE ALL ON FUNCTION public.notify_new_order() FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_stock_change() FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.enforce_admin_limit() FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.transfer_ownership(uuid) FROM anon;