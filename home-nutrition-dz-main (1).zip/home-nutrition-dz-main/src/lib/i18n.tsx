import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

export type Lang = "en" | "fr" | "ar";
export const LANGS: { code: Lang; label: string }[] = [
  { code: "en", label: "English" },
  { code: "fr", label: "Français" },
  { code: "ar", label: "العربية" },
];

const STORAGE_KEY = "hn-lang";

type Dict = Record<string, string>;

const en: Dict = {
  brand: "Home Nutrition",
  tagline: "Premium supplements, delivered across Algeria",
  heroPhrase: "Your transformation starts here.",
  home: "Home",
  shop: "Shop",
  categories: "Categories",
  packs: "Packs",
  cart: "Cart",
  checkout: "Checkout",
  track: "Track order",
  account: "Account",
  admin: "Admin",
  signIn: "Sign in",
  signUp: "Create account",
  signOut: "Sign out",
  search: "Search products",
  searchPlaceholder: "Search by product name…",
  featured: "Featured",
  bestSellers: "Best sellers",
  shopNow: "Shop now",
  viewAll: "View all",
  addToCart: "Add to cart",
  outOfStock: "Out of stock",
  inStock: "In stock",
  lowStock: "Only {n} left",
  price: "Price",
  rating: "Rating",
  availability: "Availability",
  filters: "Filters",
  clearFilters: "Clear filters",
  allCategories: "All categories",
  sort: "Sort",
  newest: "Newest",
  priceLow: "Price: low to high",
  priceHigh: "Price: high to low",
  topRated: "Top rated",
  noResults: "No products match your search.",
  quantity: "Quantity",
  subtotal: "Subtotal",
  delivery: "Delivery",
  total: "Total",
  emptyCart: "Your cart is empty",
  continueShopping: "Continue shopping",
  remove: "Remove",
  proceedToCheckout: "Proceed to checkout",
  freeDelivery: "Free delivery over {n}",
  swipeToExplore: "Swipe to explore",
  nProducts: "{n} products",
  deliveryInfo: "Delivery across all 58 wilayas",
  fullName: "Full name",
  phone: "Phone number",
  wilaya: "Wilaya",
  commune: "Commune / Region",
  address: "Delivery address",
  deliveryMethod: "Delivery method",
  homeDelivery: "Home delivery",
  deskDelivery: "Desk / Bureau delivery",
  notes: "Order notes (optional)",
  placeOrder: "Confirm order",
  cashOnDelivery: "Payment: cash on delivery",
  orderSummary: "Order summary",
  orderConfirmed: "Order confirmed!",
  orderNumber: "Order number",
  orderThanks: "We received your order. Our team will call you to confirm.",
  trackTitle: "Track your order",
  trackHint: "Enter your order number and the phone number you used.",
  trackBtn: "Track",
  status: "Status",
  reviews: "Reviews",
  writeReview: "Write a review",
  yourRating: "Your rating",
  yourReview: "Your review",
  submitReview: "Submit review",
  signInToReview: "Sign in to write a review",
  avgRating: "Average rating",
  reviewCount: "{n} reviews",
  noReviews: "No reviews yet.",
  description: "Description",
  packContents: "What's inside",
  youSave: "You save {n}",
  packPrice: "Pack price",
  originalPrice: "Original price",
  email: "Email",
  password: "Password",
  myOrders: "My orders",
  noOrders: "You have no orders yet.",
  overview: "Overview",
  products: "Products",
  inventory: "Inventory",
  orders: "Orders",
  customers: "Customers",
  stock: "Stock",
  save: "Save",
  cancel: "Cancel",
  edit: "Edit",
  delete: "Delete",
  add: "Add",
  new: "New",
  confirmed: "Confirmed",
  preparing: "Preparing",
  shipped: "Shipped",
  delivered: "Delivered",
  cancelled: "Cancelled",
  language: "Language",
  discount: "Discount",
  currencyNote: "All prices in Algerian Dinar (DA)",
  algeriaOnly: "We ship inside Algeria only",
  authentic: "100% authentic products",
  support: "Support 7 days a week",
  invalidPhone: "Enter a valid Algerian phone number (e.g. 0551234567)",
  required: "This field is required",
  stockError: "Not enough stock for some items",
  addedToCart: "Added to cart",
};

const fr: Dict = {
  brand: "Home Nutrition",
  tagline: "Compléments premium, livrés partout en Algérie",
  heroPhrase: "Votre transformation commence ici.",
  home: "Accueil",
  shop: "Boutique",
  categories: "Catégories",
  packs: "Packs",
  cart: "Panier",
  checkout: "Commander",
  track: "Suivre ma commande",
  account: "Compte",
  admin: "Admin",
  signIn: "Connexion",
  signUp: "Créer un compte",
  signOut: "Déconnexion",
  search: "Rechercher",
  searchPlaceholder: "Rechercher un produit…",
  featured: "En vedette",
  bestSellers: "Meilleures ventes",
  shopNow: "Acheter",
  viewAll: "Voir tout",
  addToCart: "Ajouter au panier",
  outOfStock: "Rupture de stock",
  inStock: "En stock",
  lowStock: "Plus que {n} en stock",
  price: "Prix",
  rating: "Note",
  availability: "Disponibilité",
  filters: "Filtres",
  clearFilters: "Réinitialiser",
  allCategories: "Toutes les catégories",
  sort: "Trier",
  newest: "Nouveautés",
  priceLow: "Prix croissant",
  priceHigh: "Prix décroissant",
  topRated: "Mieux notés",
  noResults: "Aucun produit ne correspond à votre recherche.",
  quantity: "Quantité",
  subtotal: "Sous-total",
  delivery: "Livraison",
  total: "Total",
  emptyCart: "Votre panier est vide",
  continueShopping: "Continuer mes achats",
  remove: "Retirer",
  proceedToCheckout: "Passer la commande",
  freeDelivery: "Livraison gratuite dès {n}",
  swipeToExplore: "Glissez pour explorer",
  nProducts: "{n} produits",
  deliveryInfo: "Livraison dans les 58 wilayas",
  fullName: "Nom complet",
  phone: "Numéro de téléphone",
  wilaya: "Wilaya",
  commune: "Commune / Région",
  address: "Adresse de livraison",
  deliveryMethod: "Mode de livraison",
  homeDelivery: "Livraison à domicile",
  deskDelivery: "Livraison au bureau (Stop Desk)",
  notes: "Remarques (optionnel)",
  placeOrder: "Confirmer la commande",
  cashOnDelivery: "Paiement à la livraison",
  orderSummary: "Récapitulatif",
  orderConfirmed: "Commande confirmée !",
  orderNumber: "Numéro de commande",
  orderThanks: "Nous avons reçu votre commande. Notre équipe vous appellera pour la confirmer.",
  trackTitle: "Suivre votre commande",
  trackHint: "Entrez votre numéro de commande et votre téléphone.",
  trackBtn: "Suivre",
  status: "Statut",
  reviews: "Avis",
  writeReview: "Écrire un avis",
  yourRating: "Votre note",
  yourReview: "Votre avis",
  submitReview: "Envoyer",
  signInToReview: "Connectez-vous pour laisser un avis",
  avgRating: "Note moyenne",
  reviewCount: "{n} avis",
  noReviews: "Aucun avis pour le moment.",
  description: "Description",
  packContents: "Contenu du pack",
  youSave: "Vous économisez {n}",
  packPrice: "Prix du pack",
  originalPrice: "Prix normal",
  email: "E-mail",
  password: "Mot de passe",
  myOrders: "Mes commandes",
  noOrders: "Vous n'avez aucune commande.",
  overview: "Aperçu",
  products: "Produits",
  inventory: "Stock",
  orders: "Commandes",
  customers: "Clients",
  stock: "Stock",
  save: "Enregistrer",
  cancel: "Annuler",
  edit: "Modifier",
  delete: "Supprimer",
  add: "Ajouter",
  new: "Nouvelle",
  confirmed: "Confirmée",
  preparing: "En préparation",
  shipped: "Expédiée",
  delivered: "Livrée",
  cancelled: "Annulée",
  language: "Langue",
  discount: "Remise",
  currencyNote: "Tous les prix en Dinar Algérien (DA)",
  algeriaOnly: "Livraison en Algérie uniquement",
  authentic: "Produits 100% authentiques",
  support: "Support 7j/7",
  invalidPhone: "Entrez un numéro algérien valide (ex. 0551234567)",
  required: "Ce champ est obligatoire",
  stockError: "Stock insuffisant pour certains articles",
  addedToCart: "Ajouté au panier",
};

const ar: Dict = {
  brand: "هوم نيوتريشن",
  tagline: "مكملات غذائية فاخرة، التوصيل إلى كل ولايات الجزائر",
  heroPhrase: "تحوّلك يبدأ من هنا.",
  home: "الرئيسية",
  shop: "المتجر",
  categories: "الفئات",
  packs: "الباكات",
  cart: "السلة",
  checkout: "إتمام الشراء",
  track: "تتبع الطلب",
  account: "حسابي",
  admin: "الإدارة",
  signIn: "تسجيل الدخول",
  signUp: "إنشاء حساب",
  signOut: "تسجيل الخروج",
  search: "بحث",
  searchPlaceholder: "ابحث عن منتج…",
  featured: "منتجات مميزة",
  bestSellers: "الأكثر مبيعاً",
  shopNow: "اشترِ الآن",
  viewAll: "عرض الكل",
  addToCart: "أضف إلى السلة",
  outOfStock: "غير متوفر",
  inStock: "متوفر",
  lowStock: "بقي {n} فقط",
  price: "السعر",
  rating: "التقييم",
  availability: "التوفر",
  filters: "تصفية",
  clearFilters: "إزالة التصفية",
  allCategories: "كل الفئات",
  sort: "ترتيب",
  newest: "الأحدث",
  priceLow: "السعر: من الأقل",
  priceHigh: "السعر: من الأعلى",
  topRated: "الأعلى تقييماً",
  noResults: "لا توجد منتجات مطابقة.",
  quantity: "الكمية",
  subtotal: "المجموع الفرعي",
  delivery: "التوصيل",
  total: "المجموع",
  emptyCart: "سلتك فارغة",
  continueShopping: "متابعة التسوق",
  remove: "حذف",
  proceedToCheckout: "إتمام الطلب",
  freeDelivery: "توصيل مجاني فوق {n}",
  swipeToExplore: "اسحب للاستكشاف",
  nProducts: "{n} منتج",
  deliveryInfo: "التوصيل إلى 58 ولاية",
  fullName: "الاسم الكامل",
  phone: "رقم الهاتف",
  wilaya: "الولاية",
  commune: "البلدية / المنطقة",
  address: "عنوان التوصيل",
  deliveryMethod: "طريقة التوصيل",
  homeDelivery: "التوصيل إلى المنزل",
  deskDelivery: "التوصيل إلى المكتب",
  notes: "ملاحظات (اختياري)",
  placeOrder: "تأكيد الطلب",
  cashOnDelivery: "الدفع عند الاستلام",
  orderSummary: "ملخص الطلب",
  orderConfirmed: "تم تأكيد طلبك!",
  orderNumber: "رقم الطلب",
  orderThanks: "استلمنا طلبك، سيتصل بك فريقنا للتأكيد.",
  trackTitle: "تتبع طلبك",
  trackHint: "أدخل رقم الطلب ورقم الهاتف المستعمل.",
  trackBtn: "تتبع",
  status: "الحالة",
  reviews: "التقييمات",
  writeReview: "اكتب تقييماً",
  yourRating: "تقييمك",
  yourReview: "رأيك",
  submitReview: "إرسال",
  signInToReview: "سجّل الدخول لكتابة تقييم",
  avgRating: "متوسط التقييم",
  reviewCount: "{n} تقييم",
  noReviews: "لا توجد تقييمات بعد.",
  description: "الوصف",
  packContents: "محتويات الباك",
  youSave: "توفّر {n}",
  packPrice: "سعر الباك",
  originalPrice: "السعر الأصلي",
  email: "البريد الإلكتروني",
  password: "كلمة المرور",
  myOrders: "طلباتي",
  noOrders: "لا توجد طلبات بعد.",
  overview: "نظرة عامة",
  products: "المنتجات",
  inventory: "المخزون",
  orders: "الطلبات",
  customers: "العملاء",
  stock: "المخزون",
  save: "حفظ",
  cancel: "إلغاء",
  edit: "تعديل",
  delete: "حذف",
  add: "إضافة",
  new: "جديد",
  confirmed: "مؤكد",
  preparing: "قيد التحضير",
  shipped: "تم الإرسال",
  delivered: "تم التوصيل",
  cancelled: "ملغى",
  language: "اللغة",
  discount: "تخفيض",
  currencyNote: "جميع الأسعار بالدينار الجزائري",
  algeriaOnly: "التوصيل داخل الجزائر فقط",
  authentic: "منتجات أصلية 100%",
  support: "دعم 7 أيام في الأسبوع",
  invalidPhone: "أدخل رقم هاتف جزائري صحيح (مثال 0551234567)",
  required: "هذا الحقل مطلوب",
  stockError: "المخزون غير كافٍ لبعض المنتجات",
  addedToCart: "تمت الإضافة إلى السلة",
};

const DICTS: Record<Lang, Dict> = { en, fr, ar };

type I18nValue = {
  lang: Lang;
  dir: "ltr" | "rtl";
  setLang: (l: Lang) => void;
  t: (key: keyof typeof en, vars?: Record<string, string | number>) => string;
  /** picks the right localized column from a db row */
  pick: <T extends Record<string, unknown>>(row: T, base: string) => string;
};

const I18nContext = createContext<I18nValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("fr");

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY) as Lang | null;
    if (stored && ["en", "fr", "ar"].includes(stored)) setLangState(stored);
  }, []);

  const dir: "ltr" | "rtl" = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    window.localStorage.setItem(STORAGE_KEY, l);
  }, []);

  const t = useCallback(
    (key: keyof typeof en, vars?: Record<string, string | number>) => {
      let s = DICTS[lang][key] ?? en[key] ?? String(key);
      if (vars) {
        for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, String(v));
      }
      return s;
    },
    [lang],
  );

  const pick = useCallback(
    <T extends Record<string, unknown>>(row: T, base: string) => {
      const val = row[`${base}_${lang}`] ?? row[`${base}_fr`] ?? row[`${base}_en`];
      return typeof val === "string" ? val : "";
    },
    [lang],
  );

  const value = useMemo(() => ({ lang, dir, setLang, t, pick }), [lang, dir, setLang, t, pick]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

const FALLBACK_I18N: I18nValue = {
  lang: "fr",
  dir: "ltr",
  setLang: () => {},
  t: (key, vars) => {
    let s = DICTS.fr[key] ?? en[key] ?? String(key);
    if (vars) {
      for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, String(v));
    }
    return s;
  },
  pick: (row, base) => {
    const val = row[`${base}_fr`] ?? row[`${base}_en`];
    return typeof val === "string" ? val : "";
  },
};

export function useI18n() {
  return useContext(I18nContext) ?? FALLBACK_I18N;
}
