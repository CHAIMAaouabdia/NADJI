import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const IMAGE_BUCKET = "product-images";
const MAX_IMAGE_BYTES = 6 * 1024 * 1024;

const uploadSchema = z.object({
  filename: z.string().trim().min(1).max(120),
  contentType: z.string().trim().min(3).max(80),
  /** base64 (no data: prefix) */
  data: z.string().min(16).max(12_000_000),
  folder: z.enum(["products", "packs", "categories", "branding"]).default("products"),
});

const adminIdSchema = z.object({ user_id: z.string().uuid() });

const createAdminSchema = z.object({
  email: z.string().trim().email().max(160),
  password: z.string().min(8).max(72),
  full_name: z.string().trim().min(2).max(120),
  phone: z.string().trim().max(30).optional().nullable(),
});

const updateAdminSchema = z.object({
  user_id: z.string().uuid(),
  full_name: z.string().trim().min(2).max(120).optional(),
  phone: z.string().trim().max(30).optional().nullable(),
  email: z.string().trim().email().max(160).optional(),
  is_active: z.boolean().optional(),
});

const passwordSchema = z.object({
  user_id: z.string().uuid(),
  password: z.string().min(8).max(72),
});

async function assertStaff(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("is_staff", { _user_id: userId });
  if (error || !data) throw new Error("forbidden");
}

async function assertOwner(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("is_owner", { _user_id: userId });
  if (error || !data) throw new Error("forbidden");
}

function safeName(name: string) {
  const ext = name.includes(".") ? name.slice(name.lastIndexOf(".")).toLowerCase() : ".jpg";
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext.replace(/[^a-z0-9.]/g, "")}`;
}

/** Upload an image to persistent storage. Returns a stable public URL path. */
export const uploadImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => uploadSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertStaff(context.supabase, context.userId);
    if (!data.contentType.startsWith("image/")) throw new Error("invalid_type");

    const bytes = Uint8Array.from(atob(data.data), (c) => c.charCodeAt(0));
    if (bytes.byteLength > MAX_IMAGE_BYTES) throw new Error("too_large");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const path = `${data.folder}/${safeName(data.filename)}`;
    const { error } = await supabaseAdmin.storage
      .from(IMAGE_BUCKET)
      .upload(path, bytes, { contentType: data.contentType, upsert: false });
    if (error) throw new Error(error.message);

    return { url: `/api/public/img/${path}`, path };
  });

/** Delete a previously uploaded image (only files we host). */
export const deleteStoredImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ url: z.string().min(4).max(500) }).parse(input))
  .handler(async ({ data, context }) => {
    await assertStaff(context.supabase, context.userId);
    const marker = "/api/public/img/";
    const idx = data.url.indexOf(marker);
    if (idx === -1) return { removed: false };
    const path = data.url.slice(idx + marker.length);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.storage.from(IMAGE_BUCKET).remove([path]);
    return { removed: true };
  });

/** Owner-only: create a new admin account with its own login. Max 3 active. */
export const createAdminAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => createAdminSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertOwner(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { count } = await supabaseAdmin
      .from("admin_accounts")
      .select("user_id", { count: "exact", head: true })
      .eq("is_active", true);
    if ((count ?? 0) >= 3) throw new Error("admin_limit_reached");

    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.full_name, phone: data.phone ?? null },
    });
    if (createErr || !created.user) throw new Error(createErr?.message ?? "create_failed");

    const uid = created.user.id;
    await supabaseAdmin.from("user_roles").insert({ user_id: uid, role: "admin" });
    const { error: accErr } = await supabaseAdmin.from("admin_accounts").insert({
      user_id: uid,
      email: data.email,
      full_name: data.full_name,
      phone: data.phone ?? null,
      is_active: true,
      created_by: context.userId,
    });
    if (accErr) {
      await supabaseAdmin.auth.admin.deleteUser(uid);
      throw new Error(accErr.message);
    }
    return { user_id: uid };
  });

/** Owner-only: edit admin details or enable/disable the account. */
export const updateAdminAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => updateAdminSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertOwner(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (data.is_active === true) {
      const { count } = await supabaseAdmin
        .from("admin_accounts")
        .select("user_id", { count: "exact", head: true })
        .eq("is_active", true)
        .neq("user_id", data.user_id);
      if ((count ?? 0) >= 3) throw new Error("admin_limit_reached");
    }

    const patch: {
      full_name?: string;
      phone?: string | null;
      email?: string;
      is_active?: boolean;
    } = {};
    if (data.full_name !== undefined) patch.full_name = data.full_name;
    if (data.phone !== undefined) patch.phone = data.phone ?? null;
    if (data.email !== undefined) patch.email = data.email;
    if (data.is_active !== undefined) patch.is_active = data.is_active;

    if (Object.keys(patch).length) {
      const { error } = await supabaseAdmin
        .from("admin_accounts")
        .update(patch)
        .eq("user_id", data.user_id);
      if (error) throw new Error(error.message);
    }

    if (data.email) {
      await supabaseAdmin.auth.admin.updateUserById(data.user_id, { email: data.email });
    }
    if (data.full_name !== undefined) {
      await supabaseAdmin
        .from("profiles")
        .upsert({ id: data.user_id, full_name: data.full_name, phone: data.phone ?? null });
    }
    return { ok: true };
  });

/** Owner-only: set/reset an admin password. Stored hashed by the auth service. */
export const setAdminPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => passwordSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertOwner(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.user_id, {
      password: data.password,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Owner-only: revoke admin access entirely. */
export const removeAdminAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => adminIdSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertOwner(context.supabase, context.userId);
    if (data.user_id === context.userId) throw new Error("cannot_remove_self");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("admin_accounts").delete().eq("user_id", data.user_id);
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.user_id).eq("role", "admin");
    return { ok: true };
  });

/** Owner-only: transfer ownership to an active admin. Caller becomes an admin. */
export const transferStoreOwnership = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => adminIdSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertOwner(context.supabase, context.userId);
    const { error } = await context.supabase.rpc("transfer_ownership", {
      _new_owner: data.user_id,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
