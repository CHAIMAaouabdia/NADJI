export function formatDZD(amount: number, locale = "fr"): string {
  const n = Math.round(Number(amount) || 0);
  const grouped = n.toLocaleString(locale === "ar" ? "ar-DZ" : "fr-DZ");
  return locale === "ar" ? `${grouped} دج` : `${grouped} DA`;
}

export function finalPrice(price: number | string, discountPercent: number): number {
  const p = Number(price) || 0;
  return Math.round(p * (1 - (discountPercent || 0) / 100));
}
