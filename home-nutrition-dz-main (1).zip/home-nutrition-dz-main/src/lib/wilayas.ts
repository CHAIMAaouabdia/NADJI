export type Wilaya = { code: string; name: string; nameAr: string; home: number; desk: number };

/** The 58 Algerian wilayas with delivery pricing in DZD. */
export const WILAYAS: Wilaya[] = [
  { code: "01", name: "Adrar", nameAr: "أدرار", home: 1400, desk: 900 },
  { code: "02", name: "Chlef", nameAr: "الشلف", home: 800, desk: 450 },
  { code: "03", name: "Laghouat", nameAr: "الأغواط", home: 950, desk: 600 },
  { code: "04", name: "Oum El Bouaghi", nameAr: "أم البواقي", home: 850, desk: 500 },
  { code: "05", name: "Batna", nameAr: "باتنة", home: 800, desk: 450 },
  { code: "06", name: "Béjaïa", nameAr: "بجاية", home: 800, desk: 450 },
  { code: "07", name: "Biskra", nameAr: "بسكرة", home: 900, desk: 550 },
  { code: "08", name: "Béchar", nameAr: "بشار", home: 1400, desk: 900 },
  { code: "09", name: "Blida", nameAr: "البليدة", home: 600, desk: 400 },
  { code: "10", name: "Bouira", nameAr: "البويرة", home: 750, desk: 450 },
  { code: "11", name: "Tamanrasset", nameAr: "تمنراست", home: 1600, desk: 1100 },
  { code: "12", name: "Tébessa", nameAr: "تبسة", home: 900, desk: 550 },
  { code: "13", name: "Tlemcen", nameAr: "تلمسان", home: 850, desk: 500 },
  { code: "14", name: "Tiaret", nameAr: "تيارت", home: 800, desk: 450 },
  { code: "15", name: "Tizi Ouzou", nameAr: "تيزي وزو", home: 750, desk: 450 },
  { code: "16", name: "Alger", nameAr: "الجزائر", home: 500, desk: 350 },
  { code: "17", name: "Djelfa", nameAr: "الجلفة", home: 900, desk: 550 },
  { code: "18", name: "Jijel", nameAr: "جيجل", home: 800, desk: 450 },
  { code: "19", name: "Sétif", nameAr: "سطيف", home: 750, desk: 450 },
  { code: "20", name: "Saïda", nameAr: "سعيدة", home: 850, desk: 500 },
  { code: "21", name: "Skikda", nameAr: "سكيكدة", home: 800, desk: 450 },
  { code: "22", name: "Sidi Bel Abbès", nameAr: "سيدي بلعباس", home: 850, desk: 500 },
  { code: "23", name: "Annaba", nameAr: "عنابة", home: 800, desk: 450 },
  { code: "24", name: "Guelma", nameAr: "قالمة", home: 850, desk: 500 },
  { code: "25", name: "Constantine", nameAr: "قسنطينة", home: 750, desk: 450 },
  { code: "26", name: "Médéa", nameAr: "المدية", home: 750, desk: 450 },
  { code: "27", name: "Mostaganem", nameAr: "مستغانم", home: 800, desk: 450 },
  { code: "28", name: "M'Sila", nameAr: "المسيلة", home: 850, desk: 500 },
  { code: "29", name: "Mascara", nameAr: "معسكر", home: 850, desk: 500 },
  { code: "30", name: "Ouargla", nameAr: "ورقلة", home: 1000, desk: 650 },
  { code: "31", name: "Oran", nameAr: "وهران", home: 750, desk: 450 },
  { code: "32", name: "El Bayadh", nameAr: "البيض", home: 1000, desk: 650 },
  { code: "33", name: "Illizi", nameAr: "إليزي", home: 1600, desk: 1100 },
  { code: "34", name: "Bordj Bou Arreridj", nameAr: "برج بوعريريج", home: 800, desk: 450 },
  { code: "35", name: "Boumerdès", nameAr: "بومرداس", home: 600, desk: 400 },
  { code: "36", name: "El Tarf", nameAr: "الطارف", home: 850, desk: 500 },
  { code: "37", name: "Tindouf", nameAr: "تندوف", home: 1600, desk: 1100 },
  { code: "38", name: "Tissemsilt", nameAr: "تيسمسيلت", home: 850, desk: 500 },
  { code: "39", name: "El Oued", nameAr: "الوادي", home: 1000, desk: 650 },
  { code: "40", name: "Khenchela", nameAr: "خنشلة", home: 900, desk: 550 },
  { code: "41", name: "Souk Ahras", nameAr: "سوق أهراس", home: 900, desk: 550 },
  { code: "42", name: "Tipaza", nameAr: "تيبازة", home: 600, desk: 400 },
  { code: "43", name: "Mila", nameAr: "ميلة", home: 800, desk: 450 },
  { code: "44", name: "Aïn Defla", nameAr: "عين الدفلى", home: 800, desk: 450 },
  { code: "45", name: "Naâma", nameAr: "النعامة", home: 1000, desk: 650 },
  { code: "46", name: "Aïn Témouchent", nameAr: "عين تموشنت", home: 850, desk: 500 },
  { code: "47", name: "Ghardaïa", nameAr: "غرداية", home: 1000, desk: 650 },
  { code: "48", name: "Relizane", nameAr: "غليزان", home: 800, desk: 450 },
  { code: "49", name: "Timimoun", nameAr: "تيميمون", home: 1400, desk: 900 },
  { code: "50", name: "Bordj Badji Mokhtar", nameAr: "برج باجي مختار", home: 1600, desk: 1100 },
  { code: "51", name: "Ouled Djellal", nameAr: "أولاد جلال", home: 1000, desk: 650 },
  { code: "52", name: "Béni Abbès", nameAr: "بني عباس", home: 1400, desk: 900 },
  { code: "53", name: "In Salah", nameAr: "عين صالح", home: 1600, desk: 1100 },
  { code: "54", name: "In Guezzam", nameAr: "عين قزام", home: 1600, desk: 1100 },
  { code: "55", name: "Touggourt", nameAr: "تقرت", home: 1000, desk: 650 },
  { code: "56", name: "Djanet", nameAr: "جانت", home: 1600, desk: 1100 },
  { code: "57", name: "El M'Ghair", nameAr: "المغير", home: 1000, desk: 650 },
  { code: "58", name: "El Meniaa", nameAr: "المنيعة", home: 1100, desk: 700 },
];

export const FREE_DELIVERY_THRESHOLD = 20000;

export function deliveryFeeFor(
  wilayaName: string,
  method: "home" | "desk",
  subtotal: number,
): number {
  const w = WILAYAS.find((x) => x.name === wilayaName);
  if (!w) return 0;
  if (subtotal >= FREE_DELIVERY_THRESHOLD) return 0;
  return method === "home" ? w.home : w.desk;
}

/** Algerian mobile / landline: 0[5-7]xxxxxxxx or 0[2-4]xxxxxxx */
export const ALGERIAN_PHONE_RE = /^0(5|6|7)[0-9]{8}$/;

export function normalizePhone(input: string): string {
  let v = input.replace(/[\s.-]/g, "");
  if (v.startsWith("+213")) v = "0" + v.slice(4);
  else if (v.startsWith("00213")) v = "0" + v.slice(5);
  else if (v.startsWith("213") && v.length === 12) v = "0" + v.slice(3);
  return v;
}
