import { supabase } from "@/integrations/supabase/client";

export type ProductRow = {
  id: string;
  slug: string;
  name_en: string;
  name_fr: string;
  name_ar: string;
  description_en: string | null;
  description_fr: string | null;
  description_ar: string | null;
  brand: string | null;
  price: number;
  discount_percent: number;
  images: string[];
  category_id: string | null;
  stock: number;
  featured: boolean;
  is_available: boolean;
  created_at: string;
};

export type CategoryRow = {
  id: string;
  slug: string;
  name_en: string;
  name_fr: string;
  name_ar: string;
  image_url: string | null;
  sort_order: number;
};

export type PackRow = {
  id: string;
  slug: string;
  name_en: string;
  name_fr: string;
  name_ar: string;
  description_en: string | null;
  description_fr: string | null;
  description_ar: string | null;
  image_url: string | null;
  pack_price: number;
  discount_percent: number;
  stock: number;
  featured: boolean;
  is_available: boolean;
};

export const productsQuery = {
  queryKey: ["products"],
  queryFn: async (): Promise<ProductRow[]> => {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as ProductRow[];
  },
};

export const categoriesQuery = {
  queryKey: ["categories"],
  queryFn: async (): Promise<CategoryRow[]> => {
    const { data, error } = await supabase
      .from("categories")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) throw error;
    return (data ?? []) as unknown as CategoryRow[];
  },
};

export const packsQuery = {
  queryKey: ["packs"],
  queryFn: async (): Promise<PackRow[]> => {
    const { data, error } = await supabase.from("packs").select("*").order("created_at");
    if (error) throw error;
    return (data ?? []) as unknown as PackRow[];
  },
};

export type RatingAgg = { count: number; avg: number; dist: Record<number, number> };

export const ratingsQuery = {
  queryKey: ["ratings"],
  queryFn: async (): Promise<Record<string, RatingAgg>> => {
    const { data, error } = await supabase.from("reviews_public").select("product_id, rating");
    if (error) throw error;
    const map: Record<string, RatingAgg> = {};
    for (const r of (data ?? []) as { product_id: string; rating: number }[]) {
      const row = (map[r.product_id] ??= { count: 0, avg: 0, dist: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 } });
      row.count += 1;
      row.dist[r.rating] = (row.dist[r.rating] ?? 0) + 1;
    }
    for (const key of Object.keys(map)) {
      const row = map[key]!;
      const sum = Object.entries(row.dist).reduce((s, [k, v]) => s + Number(k) * v, 0);
      row.avg = row.count ? sum / row.count : 0;
    }
    return map;
  },
};

export const packItemsQuery = {
  queryKey: ["pack_items"],
  queryFn: async () => {
    const { data, error } = await supabase.from("pack_items").select("pack_id, product_id, quantity");
    if (error) throw error;
    return data ?? [];
  },
};
