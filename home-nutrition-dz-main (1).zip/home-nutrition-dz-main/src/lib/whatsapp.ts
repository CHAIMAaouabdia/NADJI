import { formatDZD } from "./format";

/** Convert any Algerian phone input to an international wa.me number (213…). */
export function waNumber(raw: string): string {
  let v = (raw || "").replace(/[^\d+]/g, "");
  if (v.startsWith("+")) v = v.slice(1);
  if (v.startsWith("00")) v = v.slice(2);
  if (v.startsWith("0")) v = "213" + v.slice(1);
  if (!v.startsWith("213") && v.length === 9) v = "213" + v;
  return v;
}

export function waLink(number: string, message?: string): string {
  const n = waNumber(number);
  const q = message ? `?text=${encodeURIComponent(message)}` : "";
  return `https://wa.me/${n}${q}`;
}

export type WaOrderLine = { name: string; quantity: number; price: number };

export type WaOrderInfo = {
  storeName: string;
  orderNumber?: string | undefined;
  fullName?: string | undefined;
  phone?: string | undefined;
  wilaya?: string | undefined;
  commune?: string | undefined;
  address?: string | undefined;
  method?: "home" | "desk" | undefined;
  notes?: string | undefined;
  items: WaOrderLine[];
  subtotal: number;
  deliveryFee?: number | undefined;
  total: number;
  lang?: string | undefined;
};

/** Human-readable pre-filled WhatsApp order message. */
export function buildOrderMessage(info: WaOrderInfo): string {
  const l = info.lang ?? "fr";
  const lines: string[] = [];
  lines.push(`🛒 ${info.storeName} — ${info.orderNumber ? `Commande ${info.orderNumber}` : "Nouvelle commande"}`);
  lines.push("");
  for (const it of info.items) {
    lines.push(`• ${it.name} × ${it.quantity} — ${formatDZD(it.price * it.quantity, l)}`);
  }
  lines.push("");
  lines.push(`Sous-total: ${formatDZD(info.subtotal, l)}`);
  if (typeof info.deliveryFee === "number") {
    lines.push(`Livraison: ${formatDZD(info.deliveryFee, l)}`);
  }
  lines.push(`Total: ${formatDZD(info.total, l)}`);
  if (info.fullName || info.phone || info.wilaya) {
    lines.push("");
    if (info.fullName) lines.push(`Nom: ${info.fullName}`);
    if (info.phone) lines.push(`Tél: ${info.phone}`);
    if (info.wilaya) lines.push(`Wilaya: ${info.wilaya}`);
    if (info.commune) lines.push(`Commune: ${info.commune}`);
    if (info.address) lines.push(`Adresse: ${info.address}`);
    if (info.method) {
      lines.push(`Livraison: ${info.method === "home" ? "À domicile" : "Bureau / Stop desk"}`);
    }
    if (info.notes) lines.push(`Notes: ${info.notes}`);
  }
  return lines.join("\n");
}
