import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { ALGERIAN_PHONE_RE, WILAYAS } from "./wilayas";

const itemSchema = z.object({
  kind: z.enum(["product", "pack"]),
  id: z.string().uuid(),
  quantity: z.number().int().min(1).max(50),
});

const orderSchema = z.object({
  full_name: z.string().trim().min(3).max(120),
  phone: z.string().trim().regex(ALGERIAN_PHONE_RE),
  wilaya: z.string().trim().min(2).max(60),
  commune: z.string().trim().min(2).max(80),
  address: z.string().trim().min(6).max(300),
  delivery_method: z.enum(["home", "desk"]),
  notes: z.string().trim().max(500).optional().nullable(),
  items: z.array(itemSchema).min(1).max(40),
  accessToken: z.string().optional().nullable(),
});

export const createOrder = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => orderSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let userId: string | null = null;
    if (data.accessToken) {
      const { data: authData } = await supabaseAdmin.auth.getUser(data.accessToken);
      userId = authData.user?.id ?? null;
    }

    const productIds = data.items.filter((i) => i.kind === "product").map((i) => i.id);
    const packIds = data.items.filter((i) => i.kind === "pack").map((i) => i.id);

    const [productsRes, packsRes, packItemsRes] = await Promise.all([
      productIds.length
        ? supabaseAdmin
            .from("products")
            .select("id, name_en, name_fr, name_ar, price, discount_percent, stock, is_available")
            .in("id", productIds)
        : Promise.resolve({ data: [], error: null }),
      packIds.length
        ? supabaseAdmin
            .from("packs")
            .select("id, name_en, name_fr, name_ar, pack_price, stock, is_available")
            .in("id", packIds)
        : Promise.resolve({ data: [], error: null }),
      packIds.length
        ? supabaseAdmin.from("pack_items").select("pack_id, product_id, quantity").in("pack_id", packIds)
        : Promise.resolve({ data: [], error: null }),
    ]);

    if (productsRes.error) throw new Error(productsRes.error.message);
    if (packsRes.error) throw new Error(packsRes.error.message);
    if (packItemsRes.error) throw new Error(packItemsRes.error.message);

    const products = productsRes.data ?? [];
    const packs = packsRes.data ?? [];
    const packItems = packItemsRes.data ?? [];

    type Line = {
      product_id: string | null;
      pack_id: string | null;
      item_name: string;
      unit_price: number;
      quantity: number;
      line_total: number;
    };
    const lines: Line[] = [];
    // how many units of each product must be pulled out of inventory
    const productDelta = new Map<string, number>();
    const packDelta = new Map<string, number>();

    for (const item of data.items) {
      if (item.kind === "product") {
        const p = products.find((x) => x.id === item.id);
        if (!p || !p.is_available) throw new Error(`unavailable:${item.id}`);
        const unit = Math.round(Number(p.price) * (1 - (p.discount_percent ?? 0) / 100));
        productDelta.set(item.id, (productDelta.get(item.id) ?? 0) + item.quantity);
        lines.push({
          product_id: p.id,
          pack_id: null,
          item_name: p.name_en,
          unit_price: unit,
          quantity: item.quantity,
          line_total: unit * item.quantity,
        });
      } else {
        const pk = packs.find((x) => x.id === item.id);
        if (!pk || !pk.is_available) throw new Error(`unavailable:${item.id}`);
        const unit = Math.round(Number(pk.pack_price));
        packDelta.set(item.id, (packDelta.get(item.id) ?? 0) + item.quantity);
        for (const pi of packItems.filter((x) => x.pack_id === pk.id)) {
          productDelta.set(
            pi.product_id,
            (productDelta.get(pi.product_id) ?? 0) + pi.quantity * item.quantity,
          );
        }
        lines.push({
          product_id: null,
          pack_id: pk.id,
          item_name: pk.name_en,
          unit_price: unit,
          quantity: item.quantity,
          line_total: unit * item.quantity,
        });
      }
    }

    // stock validation (packs consume their component products too)
    const allProductIds = [...productDelta.keys()];
    if (allProductIds.length) {
      const { data: stockRows, error: stockErr } = await supabaseAdmin
        .from("products")
        .select("id, stock, name_en")
        .in("id", allProductIds);
      if (stockErr) throw new Error(stockErr.message);
      for (const [id, qty] of productDelta) {
        const row = stockRows?.find((r) => r.id === id);
        if (!row || row.stock < qty) throw new Error("out_of_stock");
      }
    }
    for (const [id, qty] of packDelta) {
      const pk = packs.find((p) => p.id === id);
      if (!pk || pk.stock < qty) throw new Error("out_of_stock");
    }

    const subtotal = lines.reduce((s, l) => s + l.line_total, 0);
    // delivery pricing comes from owner-managed store settings, with wilaya defaults as fallback
    const { data: settings } = await supabaseAdmin
      .from("store_settings")
      .select("free_delivery_threshold, delivery_prices, home_delivery_enabled, desk_delivery_enabled")
      .maybeSingle();
    if (settings) {
      if (data.delivery_method === "home" && !settings.home_delivery_enabled)
        throw new Error("method_disabled");
      if (data.delivery_method === "desk" && !settings.desk_delivery_enabled)
        throw new Error("method_disabled");
    }
    const wil = WILAYAS.find((w) => w.name === data.wilaya);
    const overrides = (settings?.delivery_prices ?? {}) as Record<
      string,
      { home?: number; desk?: number } | undefined
    >;
    const override = wil ? overrides[wil.code]?.[data.delivery_method] : undefined;
    const basePrice =
      typeof override === "number" ? override : wil ? wil[data.delivery_method] : 0;
    const threshold = settings?.free_delivery_threshold ?? 20000;
    const deliveryFee = subtotal >= threshold ? 0 : basePrice;
    const total = subtotal + deliveryFee;

    const { data: order, error: orderErr } = await supabaseAdmin
      .from("orders")
      .insert({
        user_id: userId,
        full_name: data.full_name,
        phone: data.phone,
        wilaya: data.wilaya,
        commune: data.commune,
        address: data.address,
        delivery_method: data.delivery_method,
        notes: data.notes ?? null,
        subtotal,
        delivery_fee: deliveryFee,
        total,
      })
      .select("id, order_number")
      .single();
    if (orderErr || !order) throw new Error(orderErr?.message ?? "order_failed");

    const { error: itemsErr } = await supabaseAdmin
      .from("order_items")
      .insert(lines.map((l) => ({ ...l, order_id: order.id })));
    if (itemsErr) throw new Error(itemsErr.message);

    // decrement inventory
    for (const [id, qty] of productDelta) {
      const { data: cur } = await supabaseAdmin.from("products").select("stock").eq("id", id).single();
      await supabaseAdmin
        .from("products")
        .update({ stock: Math.max(0, (cur?.stock ?? 0) - qty) })
        .eq("id", id);
    }
    for (const [id, qty] of packDelta) {
      const { data: cur } = await supabaseAdmin.from("packs").select("stock").eq("id", id).single();
      await supabaseAdmin
        .from("packs")
        .update({ stock: Math.max(0, (cur?.stock ?? 0) - qty) })
        .eq("id", id);
    }

    return { order_number: order.order_number, total, subtotal, delivery_fee: deliveryFee };
  });

const trackSchema = z.object({
  order_number: z.string().trim().min(4).max(40),
  phone: z.string().trim().min(9).max(20),
});

export const trackOrder = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => trackSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order } = await supabaseAdmin
      .from("orders")
      .select(
        "order_number, status, full_name, wilaya, commune, delivery_method, subtotal, delivery_fee, total, created_at",
      )
      .eq("order_number", data.order_number.toUpperCase())
      .eq("phone", data.phone)
      .maybeSingle();
    if (!order) return { found: false as const };

    const { data: items } = await supabaseAdmin
      .from("order_items")
      .select("item_name, unit_price, quantity, line_total, order_id")
      .eq(
        "order_id",
        (
          await supabaseAdmin
            .from("orders")
            .select("id")
            .eq("order_number", order.order_number)
            .single()
        ).data!.id,
      );

    return { found: true as const, order, items: items ?? [] };
  });
