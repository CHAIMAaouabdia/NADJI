import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { WILAYAS } from "./wilayas";

export type ExtraLink = { label: string; url: string };

export type StoreSettings = {
  store_name: string;
  logo_url: string | null;
  whatsapp: string;
  phone: string;
  email: string;
  facebook: string;
  instagram: string;
  tiktok: string;
  extra_links: ExtraLink[];
  footer_text: string;
  delivery_info: string;
  free_delivery_threshold: number;
  promo_banner_enabled: boolean;
  home_delivery_enabled: boolean;
  desk_delivery_enabled: boolean;
  /** wilaya code -> { home, desk } override in DZD */
  delivery_prices: Record<string, { home?: number; desk?: number }>;
};

export const DEFAULT_SETTINGS: StoreSettings = {
  store_name: "Home Nutrition",
  logo_url: null,
  whatsapp: "",
  phone: "",
  email: "",
  facebook: "",
  instagram: "",
  tiktok: "",
  extra_links: [],
  footer_text: "",
  delivery_info: "",
  free_delivery_threshold: 20000,
  promo_banner_enabled: true,
  home_delivery_enabled: true,
  desk_delivery_enabled: true,
  delivery_prices: {},
};

export function normalizeSettings(row: Record<string, unknown> | null | undefined): StoreSettings {
  if (!row) return DEFAULT_SETTINGS;
  return {
    ...DEFAULT_SETTINGS,
    ...row,
    extra_links: Array.isArray(row["extra_links"]) ? (row["extra_links"] as ExtraLink[]) : [],
    delivery_prices:
      row["delivery_prices"] && typeof row["delivery_prices"] === "object"
        ? (row["delivery_prices"] as StoreSettings["delivery_prices"])
        : {},
  } as StoreSettings;
}

export const settingsQuery = {
  queryKey: ["store-settings"],
  queryFn: async (): Promise<StoreSettings> => {
    const { data, error } = await supabase.from("store_settings").select("*").maybeSingle();
    if (error) throw error;
    return normalizeSettings(data as unknown as Record<string, unknown>);
  },
  staleTime: 60_000,
};

export function useSettings(): StoreSettings {
  const { data } = useQuery({ ...settingsQuery, placeholderData: DEFAULT_SETTINGS });
  return data ?? DEFAULT_SETTINGS;
}

export function wilayaPrice(
  settings: StoreSettings,
  wilayaName: string,
  method: "home" | "desk",
): number {
  const w = WILAYAS.find((x) => x.name === wilayaName);
  if (!w) return 0;
  const override = settings.delivery_prices?.[w.code]?.[method];
  return typeof override === "number" ? override : w[method];
}

export function deliveryFee(
  settings: StoreSettings,
  wilayaName: string,
  method: "home" | "desk",
  subtotal: number,
): number {
  if (subtotal >= settings.free_delivery_threshold) return 0;
  return wilayaPrice(settings, wilayaName, method);
}

export function enabledMethods(settings: StoreSettings): ("home" | "desk")[] {
  const out: ("home" | "desk")[] = [];
  if (settings.home_delivery_enabled) out.push("home");
  if (settings.desk_delivery_enabled) out.push("desk");
  return out.length ? out : ["home"];
}
