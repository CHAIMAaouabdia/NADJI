import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Stars } from "@/components/Stars";
import { useCart } from "@/lib/cart";
import { finalPrice, formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import type { ProductRow, RatingAgg } from "@/lib/queries";

export function ProductCard({
  product,
  rating,
}: {
  product: ProductRow;
  rating?: RatingAgg | undefined;
}) {
  const { t, pick, lang } = useI18n();
  const cart = useCart();
  const price = finalPrice(product.price, product.discount_percent);
  const soldOut = !product.is_available || product.stock <= 0;
  const name = pick(product, "name");

  return (
    <article className="group card-surface overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:border-primary/40">
      <Link
        to="/product/$slug"
        params={{ slug: product.slug }}
        className="block relative aspect-square overflow-hidden bg-surface-2"
      >
        <img
          src={product.images?.[0] ?? "/images/product-whey.jpg"}
          alt={name}
          loading="lazy"
          width={1024}
          height={1024}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {product.discount_percent > 0 && (
          <span className="absolute top-3 start-3 rounded-full bg-primary px-2.5 py-1 text-xs font-bold text-primary-foreground">
            -{product.discount_percent}%
          </span>
        )}
        {soldOut && (
          <span className="absolute inset-0 grid place-items-center bg-background/70 font-display text-lg">
            {t("outOfStock")}
          </span>
        )}
      </Link>
      <div className="space-y-2 p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Stars value={rating?.avg ?? 0} />
          <span>({rating?.count ?? 0})</span>
        </div>
        <Link to="/product/$slug" params={{ slug: product.slug }}>
          <h3 className="line-clamp-2 text-base font-semibold leading-tight tracking-normal">
            {name}
          </h3>
        </Link>
        <div className="flex items-baseline gap-2">
          <span className="font-display text-xl text-primary">{formatDZD(price, lang)}</span>
          {product.discount_percent > 0 && (
            <span className="text-sm text-muted-foreground line-through">
              {formatDZD(product.price, lang)}
            </span>
          )}
        </div>
        <Button
          className="w-full"
          disabled={soldOut}
          onClick={() => {
            cart.add({
              kind: "product",
              id: product.id,
              slug: product.slug,
              name_en: product.name_en,
              name_fr: product.name_fr,
              name_ar: product.name_ar,
              image: product.images?.[0] ?? null,
              price,
              maxStock: product.stock,
            });
            toast.success(t("addedToCart"), { description: name });
          }}
        >
          <ShoppingBag className="size-4" />
          {soldOut ? t("outOfStock") : t("addToCart")}
        </Button>
      </div>
    </article>
  );
}
