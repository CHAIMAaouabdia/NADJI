import logoAsset from "@/assets/logo.jpg.asset.json";
import { useSettings } from "@/lib/settings";

export function Logo({ size = 40 }: { size?: number }) {
  const settings = useSettings();
  const name = settings.store_name || "Home Nutrition";
  const [first, ...rest] = name.split(" ");

  return (
    <span className="flex items-center gap-2.5">
      <img
        src={settings.logo_url || logoAsset.url}
        alt={name}
        width={size}
        height={size}
        className="rounded-full object-cover ring-1 ring-border"
        style={{ width: size, height: size }}
      />
      <span className="font-display text-xl leading-none tracking-wide">
        {first?.toUpperCase()}
        {rest.length > 0 && (
          <>
            <span className="text-primary">.</span>
            {rest.join(" ").toUpperCase()}
          </>
        )}
      </span>
    </span>
  );
}
