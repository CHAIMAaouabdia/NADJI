import { Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";
import type { CategoryRow } from "@/lib/queries";

/**
 * Horizontally scrolling, snap-aligned category slider.
 * Each card shows an index number, the category image and the product count.
 */
export function CategoryCarousel({
  categories,
  counts,
}: {
  categories: CategoryRow[];
  counts: Record<string, number>;
}) {
  const { t, pick } = useI18n();

  return (
    <div
      className="-mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-3 md:-mx-6 md:px-6 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      role="list"
    >
      {categories.map((c, i) => (
        <Link
          key={c.id}
          role="listitem"
          to="/shop"
          search={{ category: c.slug }}
          className="group relative w-[70vw] shrink-0 snap-start overflow-hidden rounded-3xl border border-border bg-surface sm:w-[46vw] lg:w-[24vw]"
        >
          <img
            src={c.image_url ?? "/images/product-whey.jpg"}
            alt={pick(c, "name")}
            loading="lazy"
            width={1024}
            height={1280}
            className="aspect-[4/5] w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105"
          />
          <span className="absolute start-5 top-4 font-display text-4xl text-foreground/30">
            {String(i + 1).padStart(2, "0")}
          </span>
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background via-background/80 to-transparent p-5">
            <span className="text-[11px] font-bold uppercase tracking-widest text-primary">
              {t("categories")}
            </span>
            <h3 className="font-display text-2xl leading-tight">{pick(c, "name")}</h3>
            <p className="text-xs text-muted-foreground">
              {t("nProducts", { n: String(counts[c.id] ?? 0) })}
            </p>
          </div>
        </Link>
      ))}
    </div>
  );
}
