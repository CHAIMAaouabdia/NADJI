import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  Home,
  LayoutGrid,
  Layers,
  Menu,
  Package,
  Search,
  ShieldCheck,
  ShoppingBag,
  Truck,
  User,
} from "lucide-react";
import { useState } from "react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Logo } from "@/components/Logo";
import { useCart } from "@/lib/cart";
import { useI18n } from "@/lib/i18n";
import { formatDZD } from "@/lib/format";
import { useSettings } from "@/lib/settings";
import { WhatsAppButton, WhatsAppFloat } from "@/components/WhatsAppButton";
import { Facebook, Instagram, Mail, Phone } from "lucide-react";
import { useIsAdmin, useSession } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";

export function StoreLayout({ children }: { children: ReactNode }) {
  const { t, lang } = useI18n();
  const cart = useCart();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useSession();
  const settings = useSettings();
  const { data: isAdmin } = useIsAdmin(user?.id);
  const [q, setQ] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);

  const nav = [
    { to: "/", label: t("home"), icon: Home },
    { to: "/shop", label: t("shop"), icon: LayoutGrid },
    { to: "/categories", label: t("categories"), icon: Layers },
    { to: "/packs", label: t("packs"), icon: Package },
    { to: "/track", label: t("track"), icon: Truck },
  ] as const;

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    navigate({ to: "/shop", search: { q: q || undefined } });
    setMenuOpen(false);
  }

  return (
    <div className="flex min-h-screen flex-col">
      {settings.promo_banner_enabled && (
        <div className="bg-primary py-1.5 text-center text-xs font-semibold text-primary-foreground">
          {t("freeDelivery", { n: formatDZD(settings.free_delivery_threshold, lang) })} · {t("algeriaOnly")}
        </div>
      )}

      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="container-page flex h-16 items-center gap-3">
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label={t("shop")}>
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[85vw] max-w-xs bg-surface p-0">
              <div className="border-b border-border p-4">
                <SheetTitle asChild>
                  <div>
                    <Logo size={34} />
                  </div>
                </SheetTitle>
              </div>
              <nav className="flex flex-col p-2">
                {nav.map((n) => (
                  <Link
                    key={n.to}
                    to={n.to}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-3 rounded-xl px-3 py-3 text-base font-medium hover:bg-surface-2"
                    activeProps={{ className: "text-primary" }}
                  >
                    <n.icon className="size-5" />
                    {n.label}
                  </Link>
                ))}
                <Link
                  to={user ? "/account" : "/auth"}
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-3 rounded-xl px-3 py-3 text-base font-medium hover:bg-surface-2"
                >
                  <User className="size-5" />
                  {user ? t("account") : t("signIn")}
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-3 rounded-xl px-3 py-3 text-base font-medium text-primary hover:bg-surface-2"
                  >
                    <ShieldCheck className="size-5" />
                    {t("admin")}
                  </Link>
                )}
              </nav>
              <form onSubmit={submitSearch} className="p-4">
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder={t("searchPlaceholder")}
                  maxLength={80}
                />
              </form>
            </SheetContent>
          </Sheet>

          <Link to="/" className="shrink-0">
            <Logo size={36} />
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="rounded-full px-3 py-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground transition-colors hover:text-foreground"
                activeProps={{ className: "text-foreground" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <form onSubmit={submitSearch} className="ms-auto hidden max-w-xs flex-1 md:block">
            <div className="relative">
              <Search className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("searchPlaceholder")}
                maxLength={80}
                className="ps-9"
              />
            </div>
          </form>

          <div className="ms-auto flex shrink-0 items-center gap-0.5 pe-0.5 sm:gap-1 md:ms-0">
            <ThemeToggle />
            <LanguageSwitcher />
            {isAdmin && (
              <Button asChild variant="ghost" size="icon" className="hidden lg:inline-flex">
                <Link to="/admin" aria-label={t("admin")}>
                  <ShieldCheck className="size-5 text-primary" />
                </Link>
              </Button>
            )}
            {user ? (
              <Button asChild variant="ghost" size="icon">
                <Link to="/account" aria-label={t("account")}>
                  <User className="size-5" />
                </Link>
              </Button>
            ) : (
              <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
                <Link to="/auth">{t("signIn")}</Link>
              </Button>
            )}
            <Button asChild variant="secondary" size="icon" className="relative overflow-visible">
              <Link to="/cart" aria-label={t("cart")}>
                <ShoppingBag className="size-5" />
                {cart.count > 0 && (
                  <span className="absolute end-0 top-0 grid size-4 place-items-center rounded-full bg-primary text-[10px] font-bold leading-none text-primary-foreground ring-2 ring-background">
                    {cart.count > 9 ? "9+" : cart.count}
                  </span>
                )}
              </Link>
            </Button>
          </div>

        </div>
      </header>

      <main className="flex-1 pb-24 lg:pb-0">{children}</main>

      {/* sticky mobile cart access */}
      {cart.count > 0 && (
        <Link
          to="/cart"
          className="fixed bottom-4 inset-x-4 z-40 flex items-center justify-between rounded-2xl bg-primary px-5 py-3.5 font-semibold text-primary-foreground shadow-glow lg:hidden"
        >
          <span className="flex items-center gap-2">
            <ShoppingBag className="size-5" />
            {cart.count}
          </span>
          <span className="font-display text-lg">{formatDZD(cart.subtotal, lang)}</span>
          <span className="text-sm uppercase">{t("cart")}</span>
        </Link>
      )}

      <WhatsAppFloat offset={cart.count > 0} />

      <footer className="border-t border-border bg-surface">
        <div className="container-page grid gap-8 py-12 md:grid-cols-3">
          <div className="space-y-3">
            <Logo size={40} />
            <p className="text-sm text-muted-foreground">{t("tagline")}</p>
            <p className="text-xs text-muted-foreground">{t("currencyNote")}</p>
            {settings.footer_text && (
              <p className="text-xs text-muted-foreground">{settings.footer_text}</p>
            )}
          </div>
          <div className="space-y-2 text-sm">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} className="block text-muted-foreground hover:text-primary">
                {n.label}
              </Link>
            ))}
          </div>
          <div className="space-y-2 text-sm text-muted-foreground">
            {settings.phone && (
              <a href={`tel:${settings.phone}`} className="flex items-center gap-2 hover:text-primary">
                <Phone className="size-4 text-primary" /> {settings.phone}
              </a>
            )}
            {settings.email && (
              <a href={`mailto:${settings.email}`} className="flex items-center gap-2 hover:text-primary">
                <Mail className="size-4 text-primary" /> {settings.email}
              </a>
            )}
            <p className="flex items-center gap-2">
              <ShieldCheck className="size-4 text-primary" /> {t("authentic")}
            </p>
            <p className="flex items-center gap-2">
              <Truck className="size-4 text-primary" /> {settings.delivery_info || t("deliveryInfo")}
            </p>
            <p className="flex items-center gap-2">
              <Package className="size-4 text-primary" /> {t("support")}
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1">
              {settings.whatsapp && <WhatsAppButton size="sm" label="WhatsApp" />}
              {settings.facebook && (
                <a href={settings.facebook} target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="hover:text-primary">
                  <Facebook className="size-5" />
                </a>
              )}
              {settings.instagram && (
                <a href={settings.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="hover:text-primary">
                  <Instagram className="size-5" />
                </a>
              )}
              {settings.tiktok && (
                <a href={settings.tiktok} target="_blank" rel="noopener noreferrer" className="hover:text-primary">
                  TikTok
                </a>
              )}
              {settings.extra_links.map((l) => (
                <a key={l.url} href={l.url} target="_blank" rel="noopener noreferrer" className="hover:text-primary">
                  {l.label}
                </a>
              ))}
            </div>
          </div>
        </div>
        <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} {settings.store_name} — {t("algeriaOnly")}
          {user && (
            <button onClick={signOut} className="ms-3 underline hover:text-foreground">
              {t("signOut")}
            </button>
          )}
        </div>
      </footer>
    </div>
  );
}
