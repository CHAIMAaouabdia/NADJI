import { useSettings } from "@/lib/settings";
import { waLink } from "@/lib/whatsapp";
import { cn } from "@/lib/utils";

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className={className}>
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.51-1.761-1.684-2.059-.173-.297-.018-.458.13-.606.13-.13.298-.347.446-.52.149-.174.199-.298.298-.497.099-.198.05-.372-.05-.52-.099-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.372-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.263.489 1.694.625.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
      <path d="M12.05 0h-.007C5.412 0 .01 5.404.01 12.045a11.98 11.98 0 0 0 1.63 6.044L.05 24l6.07-1.59a11.99 11.99 0 0 0 5.93 1.554h.006c6.635 0 12.038-5.404 12.038-12.045C24.094 5.404 18.69 0 12.05 0zm0 21.96h-.005a9.93 9.93 0 0 1-5.06-1.385l-.363-.215-3.766.987 1.006-3.673-.236-.377a9.9 9.9 0 0 1-1.518-5.29c0-5.482 4.462-9.942 9.947-9.942 2.657 0 5.153 1.036 7.03 2.914a9.87 9.87 0 0 1 2.912 7.035c-.002 5.483-4.463 9.946-9.947 9.946z" />
    </svg>
  );
}

/** Inline WhatsApp contact / order button. */
export function WhatsAppButton({
  message,
  label,
  className,
  size = "md",
}: {
  message?: string;
  label: string;
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const settings = useSettings();
  if (!settings.whatsapp) return null;
  return (
    <a
      href={waLink(settings.whatsapp, message)}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full bg-[#25D366] font-semibold text-black transition-transform hover:scale-[1.02]",
        size === "sm" && "px-3 py-1.5 text-sm",
        size === "md" && "px-5 py-2.5 text-sm",
        size === "lg" && "px-6 py-3 text-base",
        className,
      )}
    >
      <WhatsAppIcon className="size-5" />
      {label}
    </a>
  );
}

/** Floating WhatsApp bubble shown on every page. */
export function WhatsAppFloat({ offset = false }: { offset?: boolean }) {
  const settings = useSettings();
  if (!settings.whatsapp) return null;
  return (
    <a
      href={waLink(
        settings.whatsapp,
        `Bonjour ${settings.store_name}, j'ai une question 👋`,
      )}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="WhatsApp"
      className={cn(
        "fixed end-4 z-50 grid size-14 place-items-center rounded-full bg-[#25D366] text-black shadow-lg transition-transform hover:scale-105",
        offset ? "bottom-24 lg:bottom-6" : "bottom-6",
      )}
    >
      <WhatsAppIcon className="size-7" />
    </a>
  );
}
