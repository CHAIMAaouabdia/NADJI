import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Crown, KeyRound, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import {
  createAdminAccount,
  removeAdminAccount,
  setAdminPassword,
  transferStoreOwnership,
  updateAdminAccount,
} from "@/lib/admin.functions";

type AdminRow = {
  user_id: string;
  full_name: string | null;
  email: string;
  phone: string | null;
  is_active: boolean;
};

const adminsQuery = {
  queryKey: ["admin-accounts"],
  queryFn: async (): Promise<AdminRow[]> => {
    const { data, error } = await supabase
      .from("admin_accounts")
      .select("user_id, full_name, email, phone, is_active")
      .order("created_at");
    if (error) throw error;
    return (data ?? []) as AdminRow[];
  },
};

export function AdminsAdmin({ ownerId }: { ownerId: string }) {
  const queryClient = useQueryClient();
  const { data: admins = [] } = useQuery(adminsQuery);
  const create = useServerFn(createAdminAccount);
  const update = useServerFn(updateAdminAccount);
  const setPassword = useServerFn(setAdminPassword);
  const remove = useServerFn(removeAdminAccount);
  const transfer = useServerFn(transferStoreOwnership);

  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ full_name: "", email: "", phone: "", password: "" });
  const [pwFor, setPwFor] = useState<AdminRow | null>(null);
  const [newPw, setNewPw] = useState("");
  const [ownPw, setOwnPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [transferTo, setTransferTo] = useState<AdminRow | null>(null);
  const [transferring, setTransferring] = useState(false);

  const activeCount = admins.filter((a) => a.is_active).length;
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["admin-accounts"] });

  async function submitNew() {
    if (form.password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    setBusy(true);
    try {
      await create({
        data: {
          email: form.email.trim(),
          password: form.password,
          full_name: form.full_name.trim(),
          phone: form.phone.trim() || null,
        },
      });
      toast.success("Admin created");
      setAdding(false);
      setForm({ full_name: "", email: "", phone: "", password: "" });
      refresh();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed";
      toast.error(msg.includes("admin_limit") ? "Maximum of 3 active admins reached" : "Could not create admin");
    } finally {
      setBusy(false);
    }
  }

  async function patch(row: AdminRow, values: Partial<AdminRow>) {
    try {
      await update({
        data: {
          user_id: row.user_id,
          ...(values.full_name !== undefined ? { full_name: values.full_name ?? "" } : {}),
          ...(values.phone !== undefined ? { phone: values.phone } : {}),
          ...(values.is_active !== undefined ? { is_active: values.is_active } : {}),
        },
      });
      toast.success("Admin updated");
      refresh();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed";
      toast.error(msg.includes("admin_limit") ? "Maximum of 3 active admins reached" : "Update failed");
    }
  }

  async function submitPassword() {
    if (!pwFor || newPw.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    try {
      await setPassword({ data: { user_id: pwFor.user_id, password: newPw } });
      toast.success("Password updated");
      setPwFor(null);
      setNewPw("");
    } catch {
      toast.error("Could not update password");
    }
  }

  async function changeOwnPassword() {
    if (ownPw.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    const { error } = await supabase.auth.updateUser({ password: ownPw });
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Your password was changed");
    setOwnPw("");
  }

  async function removeAdmin(row: AdminRow) {
    try {
      await remove({ data: { user_id: row.user_id } });
      toast.success("Admin removed");
      refresh();
    } catch {
      toast.error("Could not remove admin");
    }
  }

  async function confirmTransfer() {
    if (!transferTo) return;
    setTransferring(true);
    try {
      await transfer({ data: { user_id: transferTo.user_id } });
      toast.success("Ownership transferred. You are now an admin.");
      setTransferTo(null);
      window.location.reload();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed";
      toast.error(
        msg.includes("target_must_be_active_admin")
          ? "The new owner must be an active admin"
          : "Could not transfer ownership"
      );
    } finally {
      setTransferring(false);
    }
  }

  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <p className="text-sm text-muted-foreground">{activeCount} of 3 active admin accounts</p>
        <Button
          className="ms-auto rounded-full"
          onClick={() => setAdding(true)}
          disabled={activeCount >= 3}
        >
          <Plus className="size-4" /> Add admin
        </Button>
      </div>

      <div className="card-surface divide-y divide-border">
        {admins.map((a) => (
          <div key={a.user_id} className="flex flex-wrap items-center gap-3 p-4">
            <div className="min-w-44 flex-1">
              <p className="font-semibold">
                {a.full_name || a.email}
                {a.user_id === ownerId && <span className="ms-2 text-xs text-primary">OWNER</span>}
              </p>
              <p className="text-xs text-muted-foreground">
                {a.email}
                {a.phone ? ` · ${a.phone}` : ""}
              </p>
            </div>
            <Input
              defaultValue={a.full_name ?? ""}
              onBlur={(e) =>
                e.target.value !== (a.full_name ?? "") && patch(a, { full_name: e.target.value })
              }
              className="w-40"
              maxLength={120}
              aria-label="Admin name"
            />
            <label className="flex items-center gap-2 text-sm">
              <Switch
                checked={a.is_active}
                disabled={a.user_id === ownerId}
                onCheckedChange={(v) => patch(a, { is_active: v })}
              />
              {a.is_active ? "Active" : "Disabled"}
            </label>
            <Button variant="ghost" size="icon" aria-label="Reset password" onClick={() => setPwFor(a)}>
              <KeyRound className="size-4" />
            </Button>
            {a.user_id !== ownerId && a.is_active && (
              <Button
                variant="ghost"
                size="icon"
                aria-label="Transfer ownership"
                title="Transfer ownership"
                onClick={() => setTransferTo(a)}
              >
                <Crown className="size-4 text-primary" />
              </Button>
            )}
            {a.user_id !== ownerId && (
              <Button variant="ghost" size="icon" aria-label="Remove admin" onClick={() => removeAdmin(a)}>
                <Trash2 className="size-4 text-destructive" />
              </Button>
            )}
          </div>
        ))}
      </div>

      <div className="card-surface space-y-3 p-5">
        <h3 className="text-xl">Change my password</h3>
        <div className="flex flex-wrap gap-3">
          <Input
            type="password"
            value={ownPw}
            onChange={(e) => setOwnPw(e.target.value)}
            placeholder="New password (min 8 characters)"
            className="max-w-xs"
          />
          <Button onClick={changeOwnPassword} className="rounded-full">
            Update password
          </Button>
        </div>
      </div>

      <Dialog open={adding} onOpenChange={setAdding}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add admin account</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Full name</Label>
              <Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Email (login)</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Phone (optional)</Label>
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Password</Label>
              <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="rounded-full" onClick={() => setAdding(false)}>
              Cancel
            </Button>
            <Button className="rounded-full" onClick={submitNew} disabled={busy}>
              {busy ? "Creating…" : "Create admin"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!pwFor} onOpenChange={(o) => !o && setPwFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset password — {pwFor?.email}</DialogTitle>
          </DialogHeader>
          <Input
            type="password"
            value={newPw}
            onChange={(e) => setNewPw(e.target.value)}
            placeholder="New password (min 8 characters)"
          />
          <DialogFooter>
            <Button variant="secondary" className="rounded-full" onClick={() => setPwFor(null)}>
              Cancel
            </Button>
            <Button className="rounded-full" onClick={submitPassword}>
              Save password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!transferTo} onOpenChange={(o) => !o && !transferring && setTransferTo(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transfer store ownership</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            This makes <span className="font-semibold text-foreground">{transferTo?.full_name || transferTo?.email}</span>{" "}
            the new owner of the store. You will become a regular admin and will no longer be able to manage
            admin accounts or transfer ownership back. This cannot be undone from the dashboard.
          </p>
          <DialogFooter>
            <Button
              variant="secondary"
              className="rounded-full"
              onClick={() => setTransferTo(null)}
              disabled={transferring}
            >
              Cancel
            </Button>
            <Button className="rounded-full" onClick={confirmTransfer} disabled={transferring}>
              {transferring ? "Transferring…" : "Yes, transfer ownership"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
