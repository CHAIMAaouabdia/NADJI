import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Eye, EyeOff, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ImageManager } from "@/components/admin/ImageManager";
import { supabase } from "@/integrations/supabase/client";
import { categoriesQuery, productsQuery, type ProductRow } from "@/lib/queries";
import { formatDZD } from "@/lib/format";

type Draft = {
  id?: string;
  slug: string;
  name_en: string;
  name_fr: string;
  name_ar: string;
  description_en: string;
  description_fr: string;
  description_ar: string;
  brand: string;
  price: number;
  discount_percent: number;
  category_id: string | null;
  stock: number;
  featured: boolean;
  is_available: boolean;
  images: string[];
};

const EMPTY: Draft = {
  slug: "",
  name_en: "",
  name_fr: "",
  name_ar: "",
  description_en: "",
  description_fr: "",
  description_ar: "",
  brand: "",
  price: 0,
  discount_percent: 0,
  category_id: null,
  stock: 0,
  featured: false,
  is_available: true,
  images: [],
};

function slugify(v: string) {
  return v
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function toDraft(p: ProductRow): Draft {
  return {
    id: p.id,
    slug: p.slug,
    name_en: p.name_en,
    name_fr: p.name_fr,
    name_ar: p.name_ar,
    description_en: p.description_en ?? "",
    description_fr: p.description_fr ?? "",
    description_ar: p.description_ar ?? "",
    brand: p.brand ?? "",
    price: Number(p.price),
    discount_percent: p.discount_percent,
    category_id: p.category_id,
    stock: p.stock,
    featured: p.featured,
    is_available: p.is_available,
    images: p.images ?? [],
  };
}

export function ProductsAdmin() {
  const queryClient = useQueryClient();
  const { data: products = [] } = useQuery(productsQuery);
  const { data: categories = [] } = useQuery(categoriesQuery);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [deleting, setDeleting] = useState<ProductRow | null>(null);
  const [q, setQ] = useState("");
  const [saving, setSaving] = useState(false);

  const filtered = products.filter((p) =>
    `${p.name_en} ${p.name_fr} ${p.name_ar} ${p.brand ?? ""}`.toLowerCase().includes(q.toLowerCase()),
  );

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["products"] });
  }

  async function save() {
    if (!draft) return;
    if (draft.name_en.trim().length < 2) {
      toast.error("Product name is required");
      return;
    }
    if (!(draft.price > 0)) {
      toast.error("Enter a valid price");
      return;
    }
    setSaving(true);
    const payload = {
      slug: draft.slug.trim() || slugify(draft.name_en),
      name_en: draft.name_en.trim(),
      name_fr: (draft.name_fr || draft.name_en).trim(),
      name_ar: (draft.name_ar || draft.name_en).trim(),
      description_en: draft.description_en,
      description_fr: draft.description_fr,
      description_ar: draft.description_ar,
      brand: draft.brand.trim() || null,
      price: Math.round(draft.price),
      discount_percent: Math.min(90, Math.max(0, Math.round(draft.discount_percent))),
      category_id: draft.category_id,
      stock: Math.max(0, Math.round(draft.stock)),
      featured: draft.featured,
      is_available: draft.is_available,
      images: draft.images,
    };
    const { error } = draft.id
      ? await supabase.from("products").update(payload).eq("id", draft.id)
      : await supabase.from("products").insert(payload);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(draft.id ? "Product updated" : "Product added");
    setDraft(null);
    refresh();
  }

  async function toggleVisible(p: ProductRow) {
    const { error } = await supabase
      .from("products")
      .update({ is_available: !p.is_available })
      .eq("id", p.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(p.is_available ? "Product hidden" : "Product visible");
    refresh();
  }

  async function toggleFeatured(p: ProductRow) {
    const { error } = await supabase.from("products").update({ featured: !p.featured }).eq("id", p.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    refresh();
  }

  async function confirmDelete() {
    if (!deleting) return;
    const { error } = await supabase.from("products").delete().eq("id", deleting.id);
    setDeleting(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Product deleted");
    refresh();
  }

  const set = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search products…"
          className="max-w-xs"
        />
        <Button onClick={() => setDraft({ ...EMPTY })} className="ms-auto rounded-full">
          <Plus className="size-4" /> Add product
        </Button>
      </div>

      <div className="card-surface divide-y divide-border">
        {filtered.map((p) => (
          <div key={p.id} className="flex flex-wrap items-center gap-3 p-3">
            <img
              src={p.images?.[0] ?? ""}
              alt=""
              className="size-14 rounded-xl border border-border object-cover"
            />
            <div className="min-w-40 flex-1">
              <p className="font-semibold">{p.name_en}</p>
              <p className="text-xs text-muted-foreground">
                {formatDZD(p.price)} · {p.discount_percent}% off · {p.stock} in stock
                {!p.is_available && " · hidden"}
              </p>
            </div>
            <Button variant="ghost" size="icon" aria-label="Featured" onClick={() => toggleFeatured(p)}>
              <Star className={`size-4 ${p.featured ? "text-primary" : ""}`} />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Visibility" onClick={() => toggleVisible(p)}>
              {p.is_available ? <Eye className="size-4" /> : <EyeOff className="size-4 text-muted-foreground" />}
            </Button>
            <Button variant="ghost" size="icon" aria-label="Edit" onClick={() => setDraft(toDraft(p))}>
              <Pencil className="size-4" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => setDeleting(p)}>
              <Trash2 className="size-4 text-destructive" />
            </Button>
          </div>
        ))}
        {filtered.length === 0 && <p className="p-5 text-muted-foreground">No products found.</p>}
      </div>

      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{draft?.id ? "Edit product" : "Add product"}</DialogTitle>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label>Name (EN)</Label>
                  <Input value={draft.name_en} maxLength={120} onChange={(e) => set({ name_en: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Name (FR)</Label>
                  <Input value={draft.name_fr} maxLength={120} onChange={(e) => set({ name_fr: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Name (AR)</Label>
                  <Input value={draft.name_ar} maxLength={120} onChange={(e) => set({ name_ar: e.target.value })} />
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label>Description (EN)</Label>
                  <Textarea value={draft.description_en} maxLength={2000} onChange={(e) => set({ description_en: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Description (FR)</Label>
                  <Textarea value={draft.description_fr} maxLength={2000} onChange={(e) => set({ description_fr: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Description (AR)</Label>
                  <Textarea value={draft.description_ar} maxLength={2000} onChange={(e) => set({ description_ar: e.target.value })} />
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-1.5">
                  <Label>Price (DA)</Label>
                  <Input type="number" min={0} value={draft.price} onChange={(e) => set({ price: Number(e.target.value) })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Discount %</Label>
                  <Input type="number" min={0} max={90} value={draft.discount_percent} onChange={(e) => set({ discount_percent: Number(e.target.value) })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Stock</Label>
                  <Input type="number" min={0} value={draft.stock} onChange={(e) => set({ stock: Number(e.target.value) })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select value={draft.category_id ?? "none"} onValueChange={(v) => set({ category_id: v === "none" ? null : v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No category</SelectItem>
                      {categories.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name_en}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Brand</Label>
                  <Input value={draft.brand} maxLength={80} onChange={(e) => set({ brand: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Slug</Label>
                  <Input value={draft.slug} maxLength={120} placeholder="auto" onChange={(e) => set({ slug: e.target.value })} />
                </div>
              </div>
              <div className="flex flex-wrap gap-6">
                <label className="flex items-center gap-2 text-sm">
                  <Switch checked={draft.featured} onCheckedChange={(v) => set({ featured: v })} /> Featured
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <Switch checked={draft.is_available} onCheckedChange={(v) => set({ is_available: v })} /> Visible in store
                </label>
              </div>
              <div className="space-y-2">
                <Label>Images — first image is the main one</Label>
                <ImageManager images={draft.images} onChange={(images) => set({ images })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" onClick={() => setDraft(null)} className="rounded-full">
              Cancel
            </Button>
            <Button onClick={save} disabled={saving} className="rounded-full">
              {saving ? "Saving…" : "Save product"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this product?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting?.name_en} will be permanently removed from the store. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete permanently</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
