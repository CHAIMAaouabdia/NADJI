import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { ImageManager } from "@/components/admin/ImageManager";
import { supabase } from "@/integrations/supabase/client";
import { settingsQuery, type StoreSettings } from "@/lib/settings";
import { WILAYAS } from "@/lib/wilayas";

export function SettingsAdmin() {
  const queryClient = useQueryClient();
  const { data } = useQuery(settingsQuery);
  const [form, setForm] = useState<StoreSettings | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (data && !form) setForm(data);
  }, [data, form]);

  if (!form) return <p className="text-muted-foreground">Loading settings…</p>;
  const set = (patch: Partial<StoreSettings>) => setForm({ ...form, ...patch });

  function setPrice(code: string, method: "home" | "desk", value: string) {
    const prices = { ...form!.delivery_prices };
    const entry = { ...(prices[code] ?? {}) };
    if (value === "") delete entry[method];
    else entry[method] = Math.max(0, Math.round(Number(value) || 0));
    prices[code] = entry;
    set({ delivery_prices: prices });
  }

  async function save() {
    setSaving(true);
    const { error } = await supabase
      .from("store_settings")
      .update({
        store_name: form!.store_name,
        logo_url: form!.logo_url,
        whatsapp: form!.whatsapp,
        phone: form!.phone,
        email: form!.email,
        facebook: form!.facebook,
        instagram: form!.instagram,
        tiktok: form!.tiktok,
        extra_links: form!.extra_links,
        footer_text: form!.footer_text,
        delivery_info: form!.delivery_info,
        free_delivery_threshold: Math.max(0, Math.round(form!.free_delivery_threshold)),
        promo_banner_enabled: form!.promo_banner_enabled,
        home_delivery_enabled: form!.home_delivery_enabled,
        desk_delivery_enabled: form!.desk_delivery_enabled,
        delivery_prices: form!.delivery_prices,
      })
      .eq("id", true);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Store settings saved");
    queryClient.invalidateQueries({ queryKey: ["store-settings"] });
  }

  return (
    <section className="space-y-6">
      <div className="card-surface space-y-4 p-5">
        <h3 className="text-xl">Store identity</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Store name</Label>
            <Input value={form.store_name} maxLength={80} onChange={(e) => set({ store_name: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>Logo</Label>
            <ImageManager
              single
              folder="branding"
              images={form.logo_url ? [form.logo_url] : []}
              onChange={(imgs) => set({ logo_url: imgs[0] ?? null })}
            />
          </div>
        </div>
      </div>

      <div className="card-surface space-y-4 p-5">
        <h3 className="text-xl">Contact & social</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          {(
            [
              ["whatsapp", "WhatsApp number (e.g. 0555123456)"],
              ["phone", "Phone number"],
              ["email", "Email"],
              ["facebook", "Facebook URL"],
              ["instagram", "Instagram URL"],
              ["tiktok", "TikTok URL"],
            ] as const
          ).map(([key, label]) => (
            <div key={key} className="space-y-1.5">
              <Label>{label}</Label>
              <Input
                value={form[key]}
                maxLength={200}
                onChange={(e) => set({ [key]: e.target.value } as Partial<StoreSettings>)}
              />
            </div>
          ))}
        </div>
        <div className="space-y-2">
          <Label>Other links</Label>
          {form.extra_links.map((l, i) => (
            <div key={i} className="flex gap-2">
              <Input
                value={l.label}
                placeholder="Label"
                onChange={(e) => {
                  const next = [...form.extra_links];
                  next[i] = { ...l, label: e.target.value };
                  set({ extra_links: next });
                }}
              />
              <Input
                value={l.url}
                placeholder="https://…"
                onChange={(e) => {
                  const next = [...form.extra_links];
                  next[i] = { ...l, url: e.target.value };
                  set({ extra_links: next });
                }}
              />
              <Button
                variant="secondary"
                className="rounded-full"
                onClick={() => set({ extra_links: form.extra_links.filter((_, j) => j !== i) })}
              >
                Remove
              </Button>
            </div>
          ))}
          <Button
            variant="secondary"
            size="sm"
            className="rounded-full"
            onClick={() => set({ extra_links: [...form.extra_links, { label: "", url: "" }] })}
          >
            Add link
          </Button>
        </div>
      </div>

      <div className="card-surface space-y-4 p-5">
        <h3 className="text-xl">Footer & delivery information</h3>
        <div className="space-y-1.5">
          <Label>Footer information</Label>
          <Textarea value={form.footer_text} maxLength={500} onChange={(e) => set({ footer_text: e.target.value })} />
        </div>
        <div className="space-y-1.5">
          <Label>Delivery information</Label>
          <Textarea value={form.delivery_info} maxLength={500} onChange={(e) => set({ delivery_info: e.target.value })} />
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Free delivery from (DA)</Label>
            <Input
              type="number"
              min={0}
              value={form.free_delivery_threshold}
              onChange={(e) => set({ free_delivery_threshold: Number(e.target.value) })}
            />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <Switch
              checked={form.promo_banner_enabled}
              onCheckedChange={(v) => set({ promo_banner_enabled: v })}
            />
            Show top promo banner
          </label>
          <label className="flex items-center gap-2 text-sm">
            <Switch checked={form.home_delivery_enabled} onCheckedChange={(v) => set({ home_delivery_enabled: v })} />
            Home delivery
          </label>
          <label className="flex items-center gap-2 text-sm">
            <Switch checked={form.desk_delivery_enabled} onCheckedChange={(v) => set({ desk_delivery_enabled: v })} />
            Desk / Bureau delivery
          </label>
        </div>
      </div>

      <div className="card-surface space-y-3 p-5">
        <h3 className="text-xl">Delivery prices per wilaya</h3>
        <p className="text-xs text-muted-foreground">Leave empty to keep the default price.</p>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {WILAYAS.map((w) => (
            <div key={w.code} className="flex items-center gap-2 text-sm">
              <span className="w-32 truncate">
                {w.code} {w.name}
              </span>
              <Input
                type="number"
                min={0}
                className="w-24"
                placeholder={String(w.home)}
                value={form.delivery_prices[w.code]?.home ?? ""}
                onChange={(e) => setPrice(w.code, "home", e.target.value)}
                aria-label={`${w.name} home price`}
              />
              <Input
                type="number"
                min={0}
                className="w-24"
                placeholder={String(w.desk)}
                value={form.delivery_prices[w.code]?.desk ?? ""}
                onChange={(e) => setPrice(w.code, "desk", e.target.value)}
                aria-label={`${w.name} desk price`}
              />
            </div>
          ))}
        </div>
      </div>

      <Button onClick={save} disabled={saving} size="lg" className="rounded-full">
        {saving ? "Saving…" : "Save settings"}
      </Button>
    </section>
  );
}
