import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Archive, ArchiveRestore, Ban, CheckCircle2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { useSettings } from "@/lib/settings";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { buildOrderMessage } from "@/lib/whatsapp";

export const STATUSES = [
  "new",
  "confirmed",
  "preparing",
  "shipped",
  "delivered",
  "cancelled",
] as const;
export type Status = (typeof STATUSES)[number];

export type AdminOrderRow = {
  id: string;
  order_number: string;
  status: Status;
  full_name: string;
  phone: string;
  wilaya: string;
  commune: string;
  address: string;
  delivery_method: "home" | "desk";
  subtotal: number;
  delivery_fee: number;
  total: number;
  archived: boolean;
  created_at: string;
};

export const adminOrdersQuery = {
  queryKey: ["admin-orders"],
  queryFn: async (): Promise<AdminOrderRow[]> => {
    const { data, error } = await supabase
      .from("orders")
      .select(
        "id, order_number, status, full_name, phone, wilaya, commune, address, delivery_method, subtotal, delivery_fee, total, archived, created_at",
      )
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as AdminOrderRow[];
  },
};

export type AdminOrderItem = {
  order_id: string;
  item_name: string;
  unit_price: number;
  quantity: number;
  line_total: number;
};

/** Ordered products/packs for every order, so admins see what was actually bought. */
export const adminOrderItemsQuery = {
  queryKey: ["admin-order-items"],
  queryFn: async (): Promise<AdminOrderItem[]> => {
    const { data, error } = await supabase
      .from("order_items")
      .select("order_id, item_name, unit_price, quantity, line_total");
    if (error) throw error;
    return (data ?? []) as AdminOrderItem[];
  },
};

export function OrdersAdmin() {
  const queryClient = useQueryClient();
  const { lang } = useI18n();
  const settings = useSettings();
  const { data: orders = [] } = useQuery(adminOrdersQuery);
  const { data: orderItems = [] } = useQuery(adminOrderItemsQuery);
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [view, setView] = useState<"active" | "archived">("active");
  const [toDelete, setToDelete] = useState<AdminOrderRow | null>(null);

  const itemsByOrder = useMemo(() => {
    const map = new Map<string, AdminOrderItem[]>();
    for (const it of orderItems) {
      const list = map.get(it.order_id) ?? [];
      list.push(it);
      map.set(it.order_id, list);
    }
    return map;
  }, [orderItems]);


  const filtered = useMemo(
    () =>
      orders.filter((o) => {
        if (view === "active" ? o.archived : !o.archived) return false;
        if (statusFilter !== "all" && o.status !== statusFilter) return false;
        const hay = `${o.order_number} ${o.full_name} ${o.phone} ${o.wilaya} ${o.commune}`.toLowerCase();
        return hay.includes(q.trim().toLowerCase());
      }),
    [orders, q, statusFilter, view],
  );

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["admin-orders"] });
    queryClient.invalidateQueries({ queryKey: ["admin-order-items"] });
  }


  async function patch(id: string, values: Partial<AdminOrderRow>) {
    const { error } = await supabase.from("orders").update(values).eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Order updated");
    refresh();
  }

  async function confirmDelete() {
    if (!toDelete) return;
    const order = toDelete;
    setToDelete(null);
    const { error: itemsErr } = await supabase.from("order_items").delete().eq("order_id", order.id);
    if (itemsErr) {
      toast.error(itemsErr.message);
      return;
    }
    const { error } = await supabase.from("orders").delete().eq("id", order.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`Order ${order.order_number} deleted`);
    refresh();
  }

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search order number, name, phone, wilaya…"
          className="max-w-sm"
        />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {STATUSES.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={view} onValueChange={(v) => setView(v as "active" | "archived")}>
          <SelectTrigger className="w-36">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="card-surface divide-y divide-border">
        {filtered.map((o) => {
          const removable = o.status === "cancelled" || o.status === "delivered";
          return (
            <div key={o.id} className="space-y-3 p-4">
              <div className="flex flex-wrap items-center gap-3">
                <div className="min-w-44 flex-1">
                  <p className="font-display text-lg">{o.order_number}</p>
                  <p className="text-xs text-muted-foreground">
                    {o.full_name} · {o.phone} · {o.commune}, {o.wilaya} ·{" "}
                    {o.delivery_method === "home" ? "Home" : "Desk"}
                  </p>
                </div>
                <span className="font-semibold">{formatDZD(o.total, lang)}</span>
                <Select value={o.status} onValueChange={(v) => patch(o.id, { status: v as Status })}>
                  <SelectTrigger className="w-36">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* ordered products */}
              <div className="rounded-xl border border-border bg-surface-2/40 p-3 text-sm">
                {(itemsByOrder.get(o.id) ?? []).length === 0 ? (
                  <p className="text-xs text-muted-foreground">No items recorded for this order.</p>
                ) : (
                  <ul className="space-y-1">
                    {(itemsByOrder.get(o.id) ?? []).map((it, i) => (
                      <li key={`${o.id}-${i}`} className="flex items-center justify-between gap-3">
                        <span className="flex-1">
                          {it.item_name} <span className="text-muted-foreground">× {it.quantity}</span>
                        </span>
                        <span className="text-muted-foreground">
                          {formatDZD(Number(it.unit_price), lang)}
                        </span>
                        <span className="w-24 text-end font-medium">
                          {formatDZD(Number(it.line_total), lang)}
                        </span>
                      </li>
                    ))}
                    <li className="flex items-center justify-between gap-3 border-t border-border pt-1 text-xs text-muted-foreground">
                      <span>Subtotal {formatDZD(Number(o.subtotal), lang)}</span>
                      <span>Delivery {formatDZD(Number(o.delivery_fee), lang)}</span>
                    </li>
                  </ul>
                )}
                {o.address && <p className="mt-2 text-xs text-muted-foreground">{o.address}</p>}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  className="rounded-full"
                  onClick={() => patch(o.id, { status: "delivered" })}
                  disabled={o.status === "delivered"}
                >
                  <CheckCircle2 className="size-4" /> Delivered
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  className="rounded-full"
                  onClick={() => patch(o.id, { status: "cancelled" })}
                  disabled={o.status === "cancelled"}
                >
                  <Ban className="size-4" /> Cancel
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  className="rounded-full"
                  onClick={() => patch(o.id, { archived: !o.archived })}
                >
                  {o.archived ? <ArchiveRestore className="size-4" /> : <Archive className="size-4" />}
                  {o.archived ? "Restore" : "Archive"}
                </Button>
                {settings.whatsapp && (
                  <WhatsAppButton
                    size="sm"
                    label="WhatsApp customer"
                    message={buildOrderMessage({
                      storeName: settings.store_name,
                      orderNumber: o.order_number,
                      fullName: o.full_name,
                      phone: o.phone,
                      wilaya: o.wilaya,
                      commune: o.commune,
                      address: o.address,
                      method: o.delivery_method,
                      items: (itemsByOrder.get(o.id) ?? []).map((it) => ({
                        name: it.item_name,
                        quantity: it.quantity,
                        price: Number(it.unit_price),
                      })),

                      subtotal: Number(o.subtotal),
                      deliveryFee: Number(o.delivery_fee),
                      total: Number(o.total),
                      lang,
                    })}
                  />
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  className="ms-auto rounded-full text-destructive"
                  disabled={!removable}
                  title={removable ? "Delete permanently" : "Only cancelled or delivered orders can be deleted"}
                  onClick={() => setToDelete(o)}
                >
                  <Trash2 className="size-4" /> Delete
                </Button>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && <p className="p-5 text-muted-foreground">No orders match.</p>}
      </div>

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Permanently delete order {toDelete?.order_number}?</AlertDialogTitle>
            <AlertDialogDescription>
              The order and all of its items will be erased from the database. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete permanently</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
