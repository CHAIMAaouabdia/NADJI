import { useEffect, useRef, useState } from "react";
import {
  Bell,
  BellOff,
  Check,
  Package,
  ShoppingBag,
  AlertTriangle,
  Trash2,
  X,
} from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export type NotificationRow = {
  id: string;
  type: string;
  title: string;
  body: string;
  order_id: string | null;
  product_id: string | null;
  is_read: boolean;
  created_at: string;
};

export const notificationsQuery = {
  queryKey: ["notifications"],
  queryFn: async (): Promise<NotificationRow[]> => {
    const { data, error } = await supabase
      .from("notifications")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(40);
    if (error) throw error;
    return (data ?? []) as unknown as NotificationRow[];
  },
  refetchInterval: 20_000,
};

const MUTE_KEY = "hn-notifications-muted";

function iconFor(type: string) {
  if (type === "new_order") return <ShoppingBag className="h-4 w-4 text-primary" />;
  if (type === "out_of_stock") return <AlertTriangle className="h-4 w-4 text-destructive" />;
  return <Package className="h-4 w-4 text-muted-foreground" />;
}

/** Bell with live alerts for new orders and stock warnings (staff only). */
export function NotificationsBell({ enabled }: { enabled: boolean }) {
  const qc = useQueryClient();
  const { data: items = [] } = useQuery({ ...notificationsQuery, enabled });
  const unread = items.filter((n) => !n.is_read);
  const seen = useRef<Set<string> | null>(null);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    setMuted(localStorage.getItem(MUTE_KEY) === "1");
  }, []);

  function toggleMute() {
    const next = !muted;
    setMuted(next);
    localStorage.setItem(MUTE_KEY, next ? "1" : "0");
    toast.success(next ? "Alerts silenced" : "Alerts turned on");
  }

  useEffect(() => {
    if (!enabled) return;
    const channel = supabase
      .channel("admin-notifications")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications" },
        () => qc.invalidateQueries({ queryKey: ["notifications"] }),
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [enabled, qc]);

  useEffect(() => {
    if (!enabled) return;
    if (seen.current === null) {
      seen.current = new Set(items.map((n) => n.id));
      return;
    }
    for (const n of unread) {
      if (!seen.current.has(n.id)) {
        seen.current.add(n.id);
        if (!muted) toast(n.title, { description: n.body });
      }
    }
  }, [items, unread, enabled, muted]);

  async function markAllRead() {
    const ids = unread.map((n) => n.id);
    if (!ids.length) return;
    await supabase.from("notifications").update({ is_read: true }).in("id", ids);
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }

  async function markRead(id: string) {
    await supabase.from("notifications").update({ is_read: true }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }

  async function removeOne(id: string) {
    const { error } = await supabase.from("notifications").delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }

  async function clearAll() {
    if (!items.length) return;
    const { error } = await supabase
      .from("notifications")
      .delete()
      .in("id", items.map((n) => n.id));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Notifications cleared");
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="relative rounded-full" aria-label="Notifications">
          {muted ? <BellOff className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
          {unread.length > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-foreground">
              {unread.length > 9 ? "9+" : unread.length}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between border-b border-border px-3 py-2">
          <p className="text-sm font-semibold">Notifications</p>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={toggleMute}
              title={muted ? "Turn alerts on" : "Silence alerts"}
              aria-label={muted ? "Turn alerts on" : "Silence alerts"}
            >
              {muted ? <BellOff className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="size-8 text-destructive"
              onClick={clearAll}
              disabled={!items.length}
              title="Delete all"
              aria-label="Delete all notifications"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={markAllRead} disabled={!unread.length}>
              <Check className="mr-1 h-3.5 w-3.5" /> Read
            </Button>
          </div>
        </div>
        {muted && (
          <p className="border-b border-border bg-muted/40 px-3 py-1.5 text-[11px] text-muted-foreground">
            Pop-up alerts are silenced. New items still appear in this list.
          </p>
        )}
        <div className="max-h-80 divide-y divide-border overflow-y-auto">
          {items.length === 0 && (
            <p className="p-4 text-sm text-muted-foreground">No notifications yet.</p>
          )}
          {items.map((n) => (
            <div
              key={n.id}
              className={`flex w-full gap-2 p-3 text-left text-sm hover:bg-muted/50 ${n.is_read ? "opacity-60" : ""}`}
            >
              <button
                type="button"
                onClick={() => markRead(n.id)}
                className="flex flex-1 gap-2 text-left"
              >
                <span className="mt-0.5">{iconFor(n.type)}</span>
                <span className="flex-1">
                  <span className="block font-medium">{n.title}</span>
                  <span className="block text-xs text-muted-foreground">{n.body}</span>
                  <span className="block text-[11px] text-muted-foreground">
                    {new Date(n.created_at).toLocaleString()}
                  </span>
                </span>
                {!n.is_read && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />}
              </button>
              <button
                type="button"
                onClick={() => removeOne(n.id)}
                className="mt-0.5 h-6 w-6 shrink-0 rounded-full text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                title="Delete"
                aria-label="Delete notification"
              >
                <X className="mx-auto h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}
