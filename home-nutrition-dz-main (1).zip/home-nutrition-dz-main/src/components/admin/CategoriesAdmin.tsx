import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ImageManager } from "@/components/admin/ImageManager";
import { supabase } from "@/integrations/supabase/client";
import { categoriesQuery, type CategoryRow } from "@/lib/queries";

type Draft = {
  id?: string;
  slug: string;
  name_en: string;
  name_fr: string;
  name_ar: string;
  image_url: string | null;
  sort_order: number;
};

const EMPTY: Draft = {
  slug: "",
  name_en: "",
  name_fr: "",
  name_ar: "",
  image_url: null,
  sort_order: 0,
};

function slugify(v: string) {
  return v
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function CategoriesAdmin() {
  const queryClient = useQueryClient();
  const { data: categories = [] } = useQuery(categoriesQuery);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [deleting, setDeleting] = useState<CategoryRow | null>(null);
  const [saving, setSaving] = useState(false);

  const set = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["categories"] });
  }

  async function save() {
    if (!draft) return;
    if (draft.name_en.trim().length < 2) {
      toast.error("Category name is required");
      return;
    }
    setSaving(true);
    const payload = {
      slug: draft.slug.trim() || slugify(draft.name_en),
      name_en: draft.name_en.trim(),
      name_fr: (draft.name_fr || draft.name_en).trim(),
      name_ar: (draft.name_ar || draft.name_en).trim(),
      image_url: draft.image_url,
      sort_order: Math.max(0, Math.round(draft.sort_order)),
    };
    const { error } = draft.id
      ? await supabase.from("categories").update(payload).eq("id", draft.id)
      : await supabase.from("categories").insert(payload);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(draft.id ? "Category updated" : "Category added");
    setDraft(null);
    refresh();
  }

  async function confirmDelete() {
    if (!deleting) return;
    const { error } = await supabase.from("categories").delete().eq("id", deleting.id);
    setDeleting(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Category deleted");
    refresh();
    queryClient.invalidateQueries({ queryKey: ["products"] });
  }

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-3">
        <p className="text-sm text-muted-foreground">{categories.length} categories</p>
        <Button onClick={() => setDraft({ ...EMPTY, sort_order: categories.length })} className="ms-auto rounded-full">
          <Plus className="size-4" /> Add category
        </Button>
      </div>

      <div className="card-surface divide-y divide-border">
        {categories.map((c) => (
          <div key={c.id} className="flex flex-wrap items-center gap-3 p-3">
            <img
              src={c.image_url ?? ""}
              alt=""
              className="size-14 rounded-xl border border-border object-cover"
            />
            <div className="min-w-40 flex-1">
              <p className="font-semibold">{c.name_en}</p>
              <p className="text-xs text-muted-foreground">
                {c.name_fr} · {c.name_ar} · /{c.slug}
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Edit"
              onClick={() =>
                setDraft({
                  id: c.id,
                  slug: c.slug,
                  name_en: c.name_en,
                  name_fr: c.name_fr,
                  name_ar: c.name_ar,
                  image_url: c.image_url,
                  sort_order: c.sort_order,
                })
              }
            >
              <Pencil className="size-4" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => setDeleting(c)}>
              <Trash2 className="size-4 text-destructive" />
            </Button>
          </div>
        ))}
        {categories.length === 0 && <p className="p-5 text-muted-foreground">No categories yet.</p>}
      </div>

      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>{draft?.id ? "Edit category" : "Add category"}</DialogTitle>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label>Name (EN)</Label>
                  <Input value={draft.name_en} maxLength={80} onChange={(e) => set({ name_en: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Name (FR)</Label>
                  <Input value={draft.name_fr} maxLength={80} onChange={(e) => set({ name_fr: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Name (AR)</Label>
                  <Input value={draft.name_ar} maxLength={80} onChange={(e) => set({ name_ar: e.target.value })} />
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label>Slug</Label>
                  <Input value={draft.slug} maxLength={80} placeholder="auto" onChange={(e) => set({ slug: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Sort order</Label>
                  <Input
                    type="number"
                    min={0}
                    value={draft.sort_order}
                    onChange={(e) => set({ sort_order: Number(e.target.value) })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Category image</Label>
                <ImageManager
                  single
                  folder="categories"
                  images={draft.image_url ? [draft.image_url] : []}
                  onChange={(next) => set({ image_url: next[0] ?? null })}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" onClick={() => setDraft(null)} className="rounded-full">
              Cancel
            </Button>
            <Button onClick={save} disabled={saving} className="rounded-full">
              {saving ? "Saving…" : "Save category"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this category?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting?.name_en} will be removed. Products in it stay in the store but lose their category.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete permanently</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
