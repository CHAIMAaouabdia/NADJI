import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Eye, EyeOff, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ImageManager } from "@/components/admin/ImageManager";
import { supabase } from "@/integrations/supabase/client";
import { packItemsQuery, packsQuery, productsQuery, type PackRow } from "@/lib/queries";
import { formatDZD } from "@/lib/format";

type Item = { product_id: string; quantity: number };

type Draft = {
  id?: string;
  slug: string;
  name_en: string;
  name_fr: string;
  name_ar: string;
  description_en: string;
  description_fr: string;
  description_ar: string;
  image_url: string | null;
  pack_price: number;
  discount_percent: number;
  stock: number;
  featured: boolean;
  is_available: boolean;
  items: Item[];
};

const EMPTY: Draft = {
  slug: "",
  name_en: "",
  name_fr: "",
  name_ar: "",
  description_en: "",
  description_fr: "",
  description_ar: "",
  image_url: null,
  pack_price: 0,
  discount_percent: 0,
  stock: 0,
  featured: false,
  is_available: true,
  items: [],
};

function slugify(v: string) {
  return v
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function PacksAdmin() {
  const queryClient = useQueryClient();
  const { data: packs = [] } = useQuery(packsQuery);
  const { data: products = [] } = useQuery(productsQuery);
  const { data: packItems = [] } = useQuery(packItemsQuery);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [deleting, setDeleting] = useState<PackRow | null>(null);
  const [saving, setSaving] = useState(false);

  const set = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["packs"] });
    queryClient.invalidateQueries({ queryKey: ["pack_items"] });
  }

  function toDraft(p: PackRow): Draft {
    return {
      id: p.id,
      slug: p.slug,
      name_en: p.name_en,
      name_fr: p.name_fr,
      name_ar: p.name_ar,
      description_en: p.description_en ?? "",
      description_fr: p.description_fr ?? "",
      description_ar: p.description_ar ?? "",
      image_url: p.image_url,
      pack_price: Number(p.pack_price),
      discount_percent: p.discount_percent ?? 0,
      stock: p.stock,
      featured: p.featured,
      is_available: p.is_available,
      items: packItems
        .filter((i) => i.pack_id === p.id)
        .map((i) => ({ product_id: i.product_id, quantity: i.quantity })),
    };
  }

  function combinedPrice(items: Item[]) {
    return items.reduce((sum, it) => {
      const p = products.find((x) => x.id === it.product_id);
      if (!p) return sum;
      const unit = Number(p.price) * (1 - p.discount_percent / 100);
      return sum + unit * it.quantity;
    }, 0);
  }

  function toggleProduct(productId: string) {
    if (!draft) return;
    const exists = draft.items.some((i) => i.product_id === productId);
    set({
      items: exists
        ? draft.items.filter((i) => i.product_id !== productId)
        : [...draft.items, { product_id: productId, quantity: 1 }],
    });
  }

  function setQuantity(productId: string, quantity: number) {
    if (!draft) return;
    set({
      items: draft.items.map((i) =>
        i.product_id === productId ? { ...i, quantity: Math.max(1, Math.round(quantity)) } : i,
      ),
    });
  }

  async function save() {
    if (!draft) return;
    if (draft.name_en.trim().length < 2) {
      toast.error("Pack name is required");
      return;
    }
    if (!(draft.pack_price > 0)) {
      toast.error("Enter a valid pack price");
      return;
    }
    if (draft.items.length === 0) {
      toast.error("Select at least one product for the pack");
      return;
    }
    setSaving(true);
    const payload = {
      slug: draft.slug.trim() || slugify(draft.name_en),
      name_en: draft.name_en.trim(),
      name_fr: (draft.name_fr || draft.name_en).trim(),
      name_ar: (draft.name_ar || draft.name_en).trim(),
      description_en: draft.description_en,
      description_fr: draft.description_fr,
      description_ar: draft.description_ar,
      image_url: draft.image_url,
      pack_price: Math.round(draft.pack_price),
      discount_percent: Math.min(90, Math.max(0, Math.round(draft.discount_percent))),
      stock: Math.max(0, Math.round(draft.stock)),
      featured: draft.featured,
      is_available: draft.is_available,
    };

    let packId = draft.id;
    if (packId) {
      const { error } = await supabase.from("packs").update(payload).eq("id", packId);
      if (error) {
        setSaving(false);
        toast.error(error.message);
        return;
      }
    } else {
      const { data, error } = await supabase.from("packs").insert(payload).select("id").single();
      if (error || !data) {
        setSaving(false);
        toast.error(error?.message ?? "Could not create pack");
        return;
      }
      packId = data.id;
    }

    await supabase.from("pack_items").delete().eq("pack_id", packId);
    const { error: itemsError } = await supabase
      .from("pack_items")
      .insert(draft.items.map((i) => ({ pack_id: packId!, product_id: i.product_id, quantity: i.quantity })));

    setSaving(false);
    if (itemsError) {
      toast.error(itemsError.message);
      return;
    }
    toast.success(draft.id ? "Pack updated" : "Pack created");
    setDraft(null);
    refresh();
  }

  async function togglePack(p: PackRow, patch: Partial<PackRow>) {
    const { error } = await supabase.from("packs").update(patch).eq("id", p.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    refresh();
  }

  async function confirmDelete() {
    if (!deleting) return;
    await supabase.from("pack_items").delete().eq("pack_id", deleting.id);
    const { error } = await supabase.from("packs").delete().eq("id", deleting.id);
    setDeleting(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Pack deleted");
    refresh();
  }

  const combined = draft ? combinedPrice(draft.items) : 0;

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-3">
        <p className="text-sm text-muted-foreground">{packs.length} packs</p>
        <Button onClick={() => setDraft({ ...EMPTY })} className="ms-auto rounded-full">
          <Plus className="size-4" /> Create pack
        </Button>
      </div>

      <div className="card-surface divide-y divide-border">
        {packs.map((p) => (
          <div key={p.id} className="flex flex-wrap items-center gap-3 p-3">
            <img src={p.image_url ?? ""} alt="" className="size-14 rounded-xl border border-border object-cover" />
            <div className="min-w-40 flex-1">
              <p className="font-semibold">{p.name_en}</p>
              <p className="text-xs text-muted-foreground">
                {formatDZD(p.pack_price)} · {packItems.filter((i) => i.pack_id === p.id).length} products ·{" "}
                {p.stock} in stock{!p.is_available && " · hidden"}
              </p>
            </div>
            <Button variant="ghost" size="icon" aria-label="Featured" onClick={() => togglePack(p, { featured: !p.featured })}>
              <Star className={`size-4 ${p.featured ? "text-primary" : ""}`} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Visibility"
              onClick={() => togglePack(p, { is_available: !p.is_available })}
            >
              {p.is_available ? <Eye className="size-4" /> : <EyeOff className="size-4 text-muted-foreground" />}
            </Button>
            <Button variant="ghost" size="icon" aria-label="Edit" onClick={() => setDraft(toDraft(p))}>
              <Pencil className="size-4" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => setDeleting(p)}>
              <Trash2 className="size-4 text-destructive" />
            </Button>
          </div>
        ))}
        {packs.length === 0 && <p className="p-5 text-muted-foreground">No packs yet.</p>}
      </div>

      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{draft?.id ? "Edit pack" : "Create pack"}</DialogTitle>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label>Name (EN)</Label>
                  <Input value={draft.name_en} maxLength={120} onChange={(e) => set({ name_en: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Name (FR)</Label>
                  <Input value={draft.name_fr} maxLength={120} onChange={(e) => set({ name_fr: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Name (AR)</Label>
                  <Input value={draft.name_ar} maxLength={120} onChange={(e) => set({ name_ar: e.target.value })} />
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label>Description (EN)</Label>
                  <Textarea value={draft.description_en} maxLength={2000} onChange={(e) => set({ description_en: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Description (FR)</Label>
                  <Textarea value={draft.description_fr} maxLength={2000} onChange={(e) => set({ description_fr: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Description (AR)</Label>
                  <Textarea value={draft.description_ar} maxLength={2000} onChange={(e) => set({ description_ar: e.target.value })} />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Products in this pack</Label>
                <div className="max-h-64 divide-y divide-border overflow-y-auto rounded-xl border border-border">
                  {products.map((p) => {
                    const item = draft.items.find((i) => i.product_id === p.id);
                    return (
                      <div key={p.id} className="flex items-center gap-3 p-2 text-sm">
                        <input
                          type="checkbox"
                          checked={!!item}
                          onChange={() => toggleProduct(p.id)}
                          aria-label={`Include ${p.name_en}`}
                          className="size-4 accent-primary"
                        />
                        <span className="flex-1">{p.name_en}</span>
                        <span className="text-muted-foreground">{formatDZD(p.price)}</span>
                        {item && (
                          <Input
                            type="number"
                            min={1}
                            value={item.quantity}
                            onChange={(e) => setQuantity(p.id, Number(e.target.value))}
                            className="w-20"
                          />
                        )}
                      </div>
                    );
                  })}
                  {products.length === 0 && <p className="p-3 text-muted-foreground">Add products first.</p>}
                </div>
                <p className="text-xs text-muted-foreground">
                  Combined product price: <strong>{formatDZD(Math.round(combined))}</strong>
                  {draft.pack_price > 0 && combined > draft.pack_price && (
                    <> · customer saves {formatDZD(Math.round(combined - draft.pack_price))}</>
                  )}
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-1.5">
                  <Label>Pack price (DA)</Label>
                  <Input type="number" min={0} value={draft.pack_price} onChange={(e) => set({ pack_price: Number(e.target.value) })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Discount %</Label>
                  <Input
                    type="number"
                    min={0}
                    max={90}
                    value={draft.discount_percent}
                    onChange={(e) => set({ discount_percent: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Stock</Label>
                  <Input type="number" min={0} value={draft.stock} onChange={(e) => set({ stock: Number(e.target.value) })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Slug</Label>
                  <Input value={draft.slug} maxLength={120} placeholder="auto" onChange={(e) => set({ slug: e.target.value })} />
                </div>
              </div>

              <div className="flex flex-wrap gap-6">
                <label className="flex items-center gap-2 text-sm">
                  <Switch checked={draft.featured} onCheckedChange={(v) => set({ featured: v })} /> Featured
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <Switch checked={draft.is_available} onCheckedChange={(v) => set({ is_available: v })} /> Visible in store
                </label>
              </div>

              <div className="space-y-2">
                <Label>Pack image</Label>
                <ImageManager
                  single
                  folder="packs"
                  images={draft.image_url ? [draft.image_url] : []}
                  onChange={(next) => set({ image_url: next[0] ?? null })}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" onClick={() => setDraft(null)} className="rounded-full">
              Cancel
            </Button>
            <Button onClick={save} disabled={saving} className="rounded-full">
              {saving ? "Saving…" : "Save pack"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this pack?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting?.name_en} will be permanently removed from the store. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete permanently</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
