import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, ArrowRight, Loader2, Star, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { deleteStoredImage, uploadImage } from "@/lib/admin.functions";

async function fileToBase64(file: File): Promise<string> {
  const buf = await file.arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buf);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

/**
 * Multi-image manager: upload, replace, delete, reorder and pick the main image.
 * The first image in the list is the main product image.
 */
export function ImageManager({
  images,
  onChange,
  folder = "products",
  single = false,
}: {
  images: string[];
  onChange: (next: string[]) => void;
  folder?: "products" | "packs" | "categories" | "branding";
  single?: boolean;
}) {
  const upload = useServerFn(uploadImage);
  const removeStored = useServerFn(deleteStoredImage);
  const inputRef = useRef<HTMLInputElement>(null);
  const replaceRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [replaceIndex, setReplaceIndex] = useState<number | null>(null);

  async function uploadFiles(files: FileList): Promise<string[]> {
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      if (!file.type.startsWith("image/")) continue;
      const res = await upload({
        data: {
          filename: file.name,
          contentType: file.type,
          data: await fileToBase64(file),
          folder,
        },
      });
      urls.push(res.url);
    }
    return urls;
  }

  async function handleAdd(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    try {
      const urls = await uploadFiles(files);
      onChange(single ? urls.slice(-1) : [...images, ...urls]);
      toast.success(urls.length > 1 ? `${urls.length} images uploaded` : "Image uploaded");
    } catch {
      toast.error("Upload failed");
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  async function handleReplace(files: FileList | null) {
    if (!files?.length || replaceIndex === null) return;
    setBusy(true);
    try {
      const [url] = await uploadFiles(files);
      if (url) {
        const old = images[replaceIndex];
        const next = images.map((v, i) => (i === replaceIndex ? url : v));
        onChange(next);
        if (old) await removeStored({ data: { url: old } }).catch(() => undefined);
        toast.success("Image replaced");
      }
    } catch {
      toast.error("Replace failed");
    } finally {
      setBusy(false);
      setReplaceIndex(null);
      if (replaceRef.current) replaceRef.current.value = "";
    }
  }

  async function handleDelete(index: number) {
    const url = images[index];
    onChange(images.filter((_, i) => i !== index));
    if (url) await removeStored({ data: { url } }).catch(() => undefined);
  }

  function move(index: number, dir: -1 | 1) {
    const next = [...images];
    const target = index + dir;
    if (target < 0 || target >= next.length) return;
    const a = next[index]!;
    next[index] = next[target]!;
    next[target] = a;
    onChange(next);
  }

  function makeMain(index: number) {
    if (index === 0) return;
    const next = [...images];
    const [img] = next.splice(index, 1);
    onChange([img!, ...next]);
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-3">
        {images.map((url, i) => (
          <div key={`${url}-${i}`} className="relative w-28 overflow-hidden rounded-xl border border-border">
            <img src={url} alt="" className="aspect-square w-full object-cover" />
            {i === 0 && !single && (
              <span className="absolute start-1 top-1 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground">
                MAIN
              </span>
            )}
            <div className="flex items-center justify-between gap-0.5 bg-surface-2 p-1">
              {!single && (
                <>
                  <button type="button" onClick={() => move(i, -1)} aria-label="Move left" className="p-1 hover:text-primary">
                    <ArrowLeft className="size-3.5" />
                  </button>
                  <button type="button" onClick={() => makeMain(i)} aria-label="Set as main" className="p-1 hover:text-primary">
                    <Star className={`size-3.5 ${i === 0 ? "text-primary" : ""}`} />
                  </button>
                  <button type="button" onClick={() => move(i, 1)} aria-label="Move right" className="p-1 hover:text-primary">
                    <ArrowRight className="size-3.5" />
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={() => {
                  setReplaceIndex(i);
                  replaceRef.current?.click();
                }}
                aria-label="Replace image"
                className="p-1 hover:text-primary"
              >
                <Upload className="size-3.5" />
              </button>
              <button type="button" onClick={() => handleDelete(i)} aria-label="Delete image" className="p-1 hover:text-destructive">
                <Trash2 className="size-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple={!single}
        className="hidden"
        onChange={(e) => handleAdd(e.target.files)}
      />
      <input
        ref={replaceRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleReplace(e.target.files)}
      />

      <Button type="button" variant="secondary" size="sm" disabled={busy} onClick={() => inputRef.current?.click()} className="rounded-full">
        {busy ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
        {single ? "Upload image" : "Upload images"}
      </Button>
    </div>
  );
}
