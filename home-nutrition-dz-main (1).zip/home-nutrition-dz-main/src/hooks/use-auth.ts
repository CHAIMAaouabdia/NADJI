import { useEffect, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useSession() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return { session, user: session?.user ?? null as User | null, loading };
}

/** Owner or an active admin account. */
export function useIsAdmin(userId: string | undefined) {
  return useQuery({
    queryKey: ["is-staff", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("is_staff", { _user_id: userId! });
      if (error) return false;
      return !!data;
    },
  });
}

export function useIsOwner(userId: string | undefined) {
  return useQuery({
    queryKey: ["is-owner", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("is_owner", { _user_id: userId! });
      if (error) return false;
      return !!data;
    },
  });
}
