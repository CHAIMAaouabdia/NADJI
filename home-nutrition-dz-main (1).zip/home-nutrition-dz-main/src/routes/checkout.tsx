import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { StoreLayout } from "@/components/StoreLayout";
import { useCart } from "@/lib/cart";
import { formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { ALGERIAN_PHONE_RE, WILAYAS } from "@/lib/wilayas";
import { deliveryFee as computeFee, enabledMethods, useSettings } from "@/lib/settings";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { buildOrderMessage } from "@/lib/whatsapp";
import { communesFor } from "@/lib/communes";
import { createOrder } from "@/lib/orders.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — Delivery Across Algeria | Home Nutrition" },
      { name: "description", content: "Enter your wilaya, commune and phone number to complete your supplement order. Home or desk delivery, payment on delivery." },
      { property: "og:title", content: "Checkout — Home Nutrition Algeria" },
      { property: "og:description", content: "Home or desk delivery to all 58 wilayas, cash on delivery." },
    ],
  }),
  component: Checkout,
});

function Checkout() {
  const cart = useCart();
  const { lang, pick, t } = useI18n();
  const navigate = useNavigate();
  const submitOrder = useServerFn(createOrder);
  const settings = useSettings();
  const methods = enabledMethods(settings);

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [wilaya, setWilaya] = useState("");
  const [commune, setCommune] = useState("");
  const [address, setAddress] = useState("");
  const [method, setMethod] = useState<"home" | "desk">("home");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const communeOptions = useMemo(() => {
    const w = WILAYAS.find((x) => x.name === wilaya);
    return communesFor(w?.code);
  }, [wilaya]);

  const fee = useMemo(
    () => (wilaya ? computeFee(settings, wilaya, method, cart.subtotal) : 0),
    [settings, wilaya, method, cart.subtotal],
  );
  const total = cart.subtotal + fee;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (cart.items.length === 0) return;
    if (fullName.trim().length < 3) {
      toast.error("Enter your full name");
      return;
    }
    if (!ALGERIAN_PHONE_RE.test(phone.trim())) {
      toast.error("Enter a valid Algerian phone number (05/06/07…)");
      return;
    }
    if (!wilaya) {
      toast.error("Select your wilaya");
      return;
    }
    if (commune.trim().length < 2) {
      toast.error("Enter your commune");
      return;
    }
    if (address.trim().length < 6) {
      toast.error("Enter your delivery address");
      return;
    }

    setBusy(true);
    try {
      const { data: sess } = await supabase.auth.getSession();
      const res = await submitOrder({
        data: {
          full_name: fullName.trim(),
          phone: phone.trim(),
          wilaya,
          commune: commune.trim(),
          address: address.trim(),
          delivery_method: method,
          notes: notes.trim() || null,
          items: cart.items.map((i) => ({ kind: i.kind, id: i.id, quantity: i.quantity })),
          accessToken: sess.session?.access_token ?? null,
        },
      });
      cart.clear();
      navigate({ to: "/order/$orderNumber", params: { orderNumber: res.order_number } });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Order failed";
      toast.error(msg.includes("out_of_stock") ? "Some items are out of stock" : "Order failed, please try again");
    } finally {
      setBusy(false);
    }
  }

  return (
    <StoreLayout>
      <div className="container-page py-8">
        <h1 className="mb-6 text-4xl">Checkout</h1>
        <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[1fr_340px]">
          <div className="card-surface space-y-4 p-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="name">Full name</Label>
                <Input id="name" value={fullName} maxLength={120} onChange={(e) => setFullName(e.target.value)} required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="phone">Phone (Algeria)</Label>
                <Input id="phone" value={phone} placeholder="0555 12 34 56" maxLength={20} onChange={(e) => setPhone(e.target.value)} required />
              </div>
              <div className="space-y-1.5">
                <Label>Wilaya</Label>
                <Select
                  value={wilaya}
                  onValueChange={(v) => {
                    setWilaya(v);
                    setCommune("");
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select wilaya" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {WILAYAS.map((w) => (
                      <SelectItem key={w.code} value={w.name}>
                        {w.code} — {lang === "ar" ? w.nameAr : w.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Commune / Region</Label>
                <Select value={commune} onValueChange={setCommune} disabled={!wilaya}>
                  <SelectTrigger>
                    <SelectValue placeholder={wilaya ? "Select commune" : "Select wilaya first"} />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {communeOptions.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="address">Delivery address</Label>
              <Input id="address" value={address} maxLength={300} onChange={(e) => setAddress(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>{t("deliveryMethod")}</Label>
              <div className="grid gap-3 sm:grid-cols-2">
                {methods.map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMethod(m)}
                    className={`rounded-2xl border p-4 text-start transition-colors ${
                      method === m ? "border-primary bg-primary/10" : "border-border"
                    }`}
                  >
                    <span className="block font-semibold">
                      {m === "home" ? t("homeDelivery") : t("deskDelivery")}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {m === "home" ? "À domicile" : "Bureau / Stop desk"}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {wilaya ? formatDZD(computeFee(settings, wilaya, m, cart.subtotal), lang) : "Select wilaya"}
                    </span>
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="notes">Notes (optional)</Label>
              <Textarea id="notes" value={notes} maxLength={500} onChange={(e) => setNotes(e.target.value)} />
            </div>
          </div>

          <aside className="card-surface h-fit space-y-3 p-5">
            <ul className="space-y-2 text-sm">
              {cart.items.map((i) => (
                <li key={i.key} className="flex justify-between gap-2">
                  <span className="text-muted-foreground">
                    {pick(i, "name")} × {i.quantity}
                  </span>
                  <span>{formatDZD(i.price * i.quantity, lang)}</span>
                </li>
              ))}
            </ul>
            <div className="border-t border-border pt-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{formatDZD(cart.subtotal, lang)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery</span>
                <span>{wilaya ? formatDZD(fee, lang) : "—"}</span>
              </div>
              <div className="mt-2 flex justify-between font-display text-2xl text-primary">
                <span>Total</span>
                <span>{formatDZD(total, lang)}</span>
              </div>
            </div>
            <Button type="submit" size="lg" disabled={busy || cart.items.length === 0} className="w-full rounded-full">
              {busy ? "Placing order…" : "Place order"}
            </Button>
            {settings.whatsapp && (
              <>
                <WhatsAppButton
                  className="w-full"
                  label="Order via WhatsApp"
                  message={buildOrderMessage({
                    storeName: settings.store_name,
                    fullName: fullName.trim() || undefined,
                    phone: phone.trim() || undefined,
                    wilaya: wilaya || undefined,
                    commune: commune.trim() || undefined,
                    address: address.trim() || undefined,
                    method,
                    notes: notes.trim() || undefined,
                    items: cart.items.map((i) => ({
                      name: pick(i, "name"),
                      quantity: i.quantity,
                      price: i.price,
                    })),
                    subtotal: cart.subtotal,
                    deliveryFee: wilaya ? fee : undefined,
                    total,
                    lang,
                  })}
                />
                <p className="text-center text-xs text-muted-foreground">
                  Prefer WhatsApp? We&apos;ll confirm your order in chat.
                </p>
              </>
            )}
            <p className="text-xs text-muted-foreground">Payment on delivery. Algeria only.</p>
          </aside>
        </form>
      </div>
    </StoreLayout>
  );
}
