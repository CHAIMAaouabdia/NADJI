import { createFileRoute, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { StoreLayout } from "@/components/StoreLayout";
import { packItemsQuery, packsQuery, productsQuery } from "@/lib/queries";
import { finalPrice, formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { useCart } from "@/lib/cart";

export const Route = createFileRoute("/pack/$slug")({
  head: () => ({
    meta: [
      { title: "Supplement Pack — Home Nutrition Algeria" },
      { name: "description", content: "See what's inside this supplement bundle, its pack price and savings. Delivered across Algeria." },
      { property: "og:title", content: "Supplement Pack — Home Nutrition" },
      { property: "og:description", content: "Bundle savings on authentic supplements, delivered in Algeria." },
    ],
  }),
  component: PackPage,
});

function PackPage() {
  const { slug } = Route.useParams();
  const { pick, lang } = useI18n();
  const cart = useCart();
  const { data: packs = [], isLoading } = useQuery(packsQuery);
  const { data: products = [] } = useQuery(productsQuery);
  const { data: packItems = [] } = useQuery(packItemsQuery);

  if (isLoading) return <StoreLayout><div className="container-page py-16" /></StoreLayout>;
  const pack = packs.find((p) => p.slug === slug);
  if (!pack) throw notFound();

  const items = packItems.filter((pi) => pi.pack_id === pack.id);
  const original = items.reduce((s, pi) => {
    const p = products.find((x) => x.id === pi.product_id);
    return s + (p ? finalPrice(p.price, p.discount_percent) * pi.quantity : 0);
  }, 0);
  const saving = Math.max(0, original - pack.pack_price);
  const inStock = pack.stock > 0 && pack.is_available;

  return (
    <StoreLayout>
      <div className="container-page grid gap-8 py-8 lg:grid-cols-2">
        <img
          src={pack.image_url ?? "/images/pack-mass.jpg"}
          alt={pick(pack, "name")}
          width={1024}
          height={1024}
          className="w-full rounded-3xl border border-border object-cover"
        />
        <div className="space-y-5">
          <h1 className="text-4xl">{pick(pack, "name")}</h1>
          <p className="text-muted-foreground">{pick(pack, "description")}</p>
          <div className="flex items-baseline gap-3">
            <span className="font-display text-4xl text-primary">{formatDZD(pack.pack_price, lang)}</span>
            {saving > 0 && (
              <span className="text-sm text-muted-foreground line-through">{formatDZD(original, lang)}</span>
            )}
          </div>
          {saving > 0 && <p className="text-sm text-primary">You save {formatDZD(saving, lang)}</p>}
          <ul className="card-surface divide-y divide-border p-2">
            {items.map((pi) => {
              const p = products.find((x) => x.id === pi.product_id);
              if (!p) return null;
              return (
                <li key={pi.product_id} className="flex items-center gap-3 p-3">
                  <img
                    src={p.images?.[0] ?? "/images/product-whey.jpg"}
                    alt={pick(p, "name")}
                    loading="lazy"
                    width={120}
                    height={120}
                    className="size-14 rounded-lg object-cover"
                  />
                  <span className="flex-1 text-sm">{pick(p, "name")}</span>
                  <span className="text-sm text-muted-foreground">× {pi.quantity}</span>
                </li>
              );
            })}
          </ul>
          <p className="text-sm">{inStock ? `In stock: ${pack.stock}` : "Out of stock"}</p>
          <Button
            size="lg"
            disabled={!inStock}
            className="w-full rounded-full sm:w-auto sm:px-10"
            onClick={() => {
              cart.add({
                kind: "pack",
                id: pack.id,
                slug: pack.slug,
                name_en: pack.name_en,
                name_fr: pack.name_fr,
                name_ar: pack.name_ar,
                image: pack.image_url,
                price: pack.pack_price,
                maxStock: pack.stock,
              });
              toast.success("Pack added to cart");
            }}
          >
            Add pack to cart
          </Button>
        </div>
      </div>
    </StoreLayout>
  );
}
