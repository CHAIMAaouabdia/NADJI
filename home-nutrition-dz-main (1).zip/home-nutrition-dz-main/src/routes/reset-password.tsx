import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { StoreLayout } from "@/components/StoreLayout";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set a New Password — Home Nutrition" },
      { name: "description", content: "Choose a new password for your Home Nutrition account." },
      { property: "og:title", content: "Set a New Password — Home Nutrition" },
      { property: "og:description", content: "Choose a new password for your Home Nutrition account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || session) setReady(true);
    });
    supabase.auth.getSession().then(({ data: s }) => {
      if (s.session) setReady(true);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    if (password !== confirm) {
      toast.error("Passwords do not match");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Password updated — you are signed in.");
    navigate({ to: "/admin" });
  }

  return (
    <StoreLayout>
      <div className="container-page max-w-md py-14">
        <h1 className="mb-6 text-4xl">New password</h1>
        {!ready && (
          <p className="mb-4 text-sm text-muted-foreground">
            Open this page from the reset link in your email to continue.
          </p>
        )}
        <form onSubmit={submit} className="card-surface space-y-4 p-5">
          <div className="space-y-1.5">
            <Label htmlFor="np">New password</Label>
            <Input
              id="np"
              type="password"
              value={password}
              minLength={8}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cp">Confirm password</Label>
            <Input
              id="cp"
              type="password"
              value={confirm}
              minLength={8}
              onChange={(e) => setConfirm(e.target.value)}
              required
            />
          </div>
          <Button type="submit" disabled={busy || !ready} className="w-full rounded-full">
            {busy ? "Saving…" : "Save new password"}
          </Button>
        </form>
      </div>
    </StoreLayout>
  );
}
