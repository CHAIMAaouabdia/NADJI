import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { StoreLayout } from "@/components/StoreLayout";
import { categoriesQuery, productsQuery } from "@/lib/queries";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Supplement Categories — Home Nutrition Algeria" },
      {
        name: "description",
        content:
          "Explore supplement categories: protein, mass gainers, pre-workout, vitamins and health. Delivered across Algeria.",
      },
      { property: "og:title", content: "Supplement Categories — Home Nutrition" },
      {
        property: "og:description",
        content: "Protein, gainers, pre-workout and vitamins for Algerian athletes.",
      },
    ],
  }),
  component: Categories,
});

function Categories() {
  const { t, pick } = useI18n();
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: products = [] } = useQuery(productsQuery);

  return (
    <StoreLayout>
      <div className="container-page py-8">
        <h1 className="mb-6 text-4xl">{t("categories")}</h1>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c) => {
            const count = products.filter((p) => p.category_id === c.id).length;
            return (
              <Link
                key={c.id}
                to="/shop"
                search={{ category: c.slug }}
                className="group card-surface overflow-hidden transition-colors hover:border-primary/40"
              >
                <img
                  src={c.image_url ?? "/images/product-whey.jpg"}
                  alt={pick(c, "name")}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="aspect-[16/10] w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="flex items-center justify-between p-5">
                  <h2 className="text-2xl">{pick(c, "name")}</h2>
                  <span className="text-sm text-muted-foreground">{count}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </StoreLayout>
  );
}
