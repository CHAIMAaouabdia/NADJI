import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StoreLayout } from "@/components/StoreLayout";
import { OrdersAdmin, adminOrdersQuery } from "@/components/admin/OrdersAdmin";
import { ProductsAdmin } from "@/components/admin/ProductsAdmin";
import { CategoriesAdmin } from "@/components/admin/CategoriesAdmin";
import { PacksAdmin } from "@/components/admin/PacksAdmin";
import { AdminsAdmin } from "@/components/admin/AdminsAdmin";
import { SettingsAdmin } from "@/components/admin/SettingsAdmin";
import { NotificationsBell } from "@/components/admin/NotificationsBell";
import { useIsAdmin, useIsOwner, useSession } from "@/hooks/use-auth";
import { productsQuery, packsQuery } from "@/lib/queries";
import { formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — Home Nutrition" },
      { name: "description", content: "Internal dashboard for managing Home Nutrition orders, products, packs, staff and store settings." },
      { property: "og:title", content: "Admin Dashboard — Home Nutrition" },
      { property: "og:description", content: "Manage orders, inventory, catalogue and store settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});

function Admin() {
  const { user, loading } = useSession();
  const { data: isStaff, isLoading: roleLoading } = useIsAdmin(user?.id);
  const { data: isOwner } = useIsOwner(user?.id);
  const { lang, pick } = useI18n();

  const { data: orders = [] } = useQuery({ ...adminOrdersQuery, enabled: !!isStaff });
  const { data: products = [] } = useQuery({ ...productsQuery, enabled: !!isStaff });
  const { data: packs = [] } = useQuery({ ...packsQuery, enabled: !!isStaff });

  if (loading || roleLoading)
    return (
      <StoreLayout>
        <div className="container-page py-16" />
      </StoreLayout>
    );

  if (!user || !isStaff) {
    return (
      <StoreLayout>
        <div className="container-page max-w-md py-20 text-center">
          <h1 className="text-3xl">Admin access only</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            This area is restricted to store administrators.
          </p>
          <Button asChild className="mt-6 rounded-full">
            <Link to={user ? "/" : "/auth"}>{user ? "Back to store" : "Sign in"}</Link>
          </Button>
        </div>
      </StoreLayout>
    );
  }

  const revenue = orders
    .filter((o) => o.status !== "cancelled")
    .reduce((s, o) => s + Number(o.total), 0);
  const lowStock = products.filter((p) => p.stock <= 5);

  return (
    <StoreLayout>
      <div className="container-page space-y-6 py-8">
        <div className="flex items-center justify-between gap-4">
          <h1 className="text-4xl">Admin dashboard</h1>
          <NotificationsBell enabled={!!isStaff} />
        </div>

        <Tabs defaultValue="overview">
          <TabsList className="flex-wrap">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="packs">Packs</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            {isOwner && <TabsTrigger value="admins">Admins</TabsTrigger>}
            {isOwner && <TabsTrigger value="settings">Settings</TabsTrigger>}
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { label: "Orders", value: String(orders.length) },
                { label: "Revenue", value: formatDZD(revenue, lang) },
                { label: "Products", value: String(products.length) },
                { label: "Packs", value: String(packs.length) },
              ].map((s) => (
                <div key={s.label} className="card-surface p-5">
                  <p className="text-xs uppercase tracking-wide text-muted-foreground">{s.label}</p>
                  <p className="font-display text-3xl text-primary">{s.value}</p>
                </div>
              ))}
            </div>
            {lowStock.length > 0 && (
              <p className="mt-4 text-sm text-destructive">{lowStock.length} product(s) low on stock.</p>
            )}
          </TabsContent>

          <TabsContent value="products" className="mt-6">
            <ProductsAdmin />
          </TabsContent>

          <TabsContent value="categories" className="mt-6">
            <CategoriesAdmin />
          </TabsContent>

          <TabsContent value="packs" className="mt-6">
            <PacksAdmin />
          </TabsContent>

          <TabsContent value="orders" className="mt-6">
            <OrdersAdmin />
          </TabsContent>

          <TabsContent value="inventory" className="mt-6">
            <div className="card-surface divide-y divide-border">
              {products.map((p) => (
                <div key={p.id} className="flex items-center gap-3 p-4 text-sm">
                  <span className="flex-1">{pick(p, "name")}</span>
                  <span className="text-muted-foreground">{formatDZD(p.price, lang)}</span>
                  <span className={p.stock <= 5 ? "font-semibold text-destructive" : ""}>
                    {p.stock} in stock
                  </span>
                </div>
              ))}
            </div>
          </TabsContent>

          {isOwner && (
            <TabsContent value="admins" className="mt-6">
              <AdminsAdmin ownerId={user.id} />
            </TabsContent>
          )}

          {isOwner && (
            <TabsContent value="settings" className="mt-6">
              <SettingsAdmin />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </StoreLayout>
  );
}
