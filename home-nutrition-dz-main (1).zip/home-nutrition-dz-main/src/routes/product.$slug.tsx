import { createFileRoute, notFound } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { StoreLayout } from "@/components/StoreLayout";
import { Stars } from "@/components/Stars";
import { productsQuery, ratingsQuery } from "@/lib/queries";
import { finalPrice, formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { useCart } from "@/lib/cart";
import { useSession } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/product/$slug")({
  head: () => ({
    meta: [
      { title: "Product — Home Nutrition Algeria" },
      { name: "description", content: "Product details, ingredients, reviews and price in DA. Delivered across all Algerian wilayas." },
      { property: "og:title", content: "Product — Home Nutrition Algeria" },
      { property: "og:description", content: "Authentic supplement with verified reviews, delivered in Algeria." },
    ],
  }),
  component: ProductPage,
});

type ReviewRow = {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  author_name: string;
};

function ProductPage() {
  const { slug } = Route.useParams();
  const { pick, lang } = useI18n();
  const cart = useCart();
  const { user } = useSession();
  const queryClient = useQueryClient();
  const { data: products = [], isLoading } = useQuery(productsQuery);
  const { data: ratings = {} } = useQuery(ratingsQuery);
  const product = products.find((p) => p.slug === slug);

  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews", product?.id],
    enabled: !!product,
    queryFn: async (): Promise<ReviewRow[]> => {
      const { data, error } = await supabase
        .from("reviews_public")
        .select("id, rating, comment, created_at, author_name")
        .eq("product_id", product!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as ReviewRow[];
    },
  });

  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);

  if (isLoading) return <StoreLayout><div className="container-page py-16" /></StoreLayout>;
  if (!product) throw notFound();

  const agg = ratings[product.id];
  const price = finalPrice(product.price, product.discount_percent);
  const inStock = product.stock > 0 && product.is_available;

  async function submitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!user) {
      toast.error("Sign in to leave a review");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("reviews").insert({
      product_id: product!.id,
      user_id: user.id,
      rating,
      comment: comment.trim() || null,
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setComment("");
    toast.success("Review submitted");
    queryClient.invalidateQueries({ queryKey: ["reviews", product!.id] });
    queryClient.invalidateQueries({ queryKey: ["ratings"] });
  }

  return (
    <StoreLayout>
      <div className="container-page grid gap-8 py-8 lg:grid-cols-2">
        <img
          src={product.images?.[0] ?? "/images/product-whey.jpg"}
          alt={pick(product, "name")}
          width={1024}
          height={1024}
          className="w-full rounded-3xl border border-border object-cover"
        />
        <div className="space-y-5">
          <h1 className="text-4xl">{pick(product, "name")}</h1>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Stars value={agg?.avg ?? 0} />
            <span>({agg?.count ?? 0})</span>
          </div>
          <p className="font-display text-4xl text-primary">{formatDZD(price, lang)}</p>
          {product.discount_percent > 0 && (
            <p className="text-sm text-muted-foreground line-through">
              {formatDZD(product.price, lang)}
            </p>
          )}
          <p className="text-muted-foreground">{pick(product, "description")}</p>
          <p className="text-sm">
            {inStock ? `In stock: ${product.stock}` : "Out of stock"}
          </p>
          <Button
            size="lg"
            disabled={!inStock}
            className="w-full rounded-full sm:w-auto sm:px-10"
            onClick={() => {
              cart.add({
                kind: "product",
                id: product.id,
                slug: product.slug,
                name_en: product.name_en,
                name_fr: product.name_fr,
                name_ar: product.name_ar,
                image: product.images?.[0] ?? null,
                price,
                maxStock: product.stock,
              });
              toast.success("Added to cart");
            }}
          >
            Add to cart
          </Button>
        </div>
      </div>

      <section className="container-page grid gap-8 py-8 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          <h2 className="text-3xl">Reviews</h2>
          {reviews.length === 0 && <p className="text-muted-foreground">No reviews yet.</p>}
          <ul className="space-y-3">
            {reviews.map((r) => (
              <li key={r.id} className="card-surface p-4">
                <Stars value={r.rating} />
                {r.comment && <p className="mt-2 text-sm text-muted-foreground">{r.comment}</p>}
                <p className="mt-1 text-xs text-muted-foreground">
                  {new Date(r.created_at).toLocaleDateString()}
                </p>
              </li>
            ))}
          </ul>
        </div>
        <aside className="card-surface h-fit space-y-4 p-5">
          <h3 className="text-xl">Rating breakdown</h3>
          {[5, 4, 3, 2, 1].map((s) => {
            const n = agg?.dist[s] ?? 0;
            const pct = agg?.count ? (n / agg.count) * 100 : 0;
            return (
              <div key={s} className="flex items-center gap-2 text-xs">
                <span className="w-3">{s}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-surface-2">
                  <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
                </div>
                <span className="w-6 text-end text-muted-foreground">{n}</span>
              </div>
            );
          })}
          <form onSubmit={submitReview} className="space-y-3 border-t border-border pt-4">
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <button key={s} type="button" onClick={() => setRating(s)} aria-label={`${s} stars`}>
                  <Stars value={s <= rating ? 5 : 0} size={16} className="w-4 overflow-hidden" />
                </button>
              ))}
            </div>
            <Textarea
              value={comment}
              maxLength={600}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Share your experience"
            />
            <Button type="submit" disabled={busy} className="w-full rounded-full">
              Submit review
            </Button>
          </form>
        </aside>
      </section>
    </StoreLayout>
  );
}
