import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { SlidersHorizontal } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { StoreLayout } from "@/components/StoreLayout";
import { ProductCard } from "@/components/ProductCard";
import { Stars } from "@/components/Stars";
import { categoriesQuery, productsQuery, ratingsQuery } from "@/lib/queries";
import { finalPrice, formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

const searchSchema = z.object({
  q: z.string().optional(),
  category: z.string().optional(),
});

export const Route = createFileRoute("/shop")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Shop Supplements — Home Nutrition Algeria" },
      {
        name: "description",
        content:
          "Browse whey protein, creatine, pre-workout, vitamins and gainers. Filter by category, price and rating. Prices in DA.",
      },
      { property: "og:title", content: "Shop Supplements — Home Nutrition Algeria" },
      {
        property: "og:description",
        content: "Search and filter authentic supplements delivered anywhere in Algeria.",
      },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { q: initialQ, category: initialCategory } = Route.useSearch();
  const { t, pick, lang } = useI18n();
  const { data: products = [], isLoading } = useQuery(productsQuery);
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: ratings = {} } = useQuery(ratingsQuery);

  const [q, setQ] = useState(initialQ ?? "");
  const [category, setCategory] = useState(initialCategory ?? "all");
  const [maxPrice, setMaxPrice] = useState(30000);
  const [minRating, setMinRating] = useState(0);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [featuredOnly, setFeaturedOnly] = useState(false);
  const [sort, setSort] = useState("newest");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    const catId = categories.find((c) => c.slug === category)?.id;
    let list = products.filter((p) => {
      const name = `${p.name_en} ${p.name_fr} ${p.name_ar}`.toLowerCase();
      if (q && !name.includes(q.toLowerCase())) return false;
      if (category !== "all" && p.category_id !== catId) return false;
      if (finalPrice(p.price, p.discount_percent) > maxPrice) return false;
      if (minRating > 0 && (ratings[p.id]?.avg ?? 0) < minRating) return false;
      if (inStockOnly && (p.stock <= 0 || !p.is_available)) return false;
      if (featuredOnly && !p.featured) return false;
      return true;
    });
    list = [...list].sort((a, b) => {
      if (sort === "priceLow")
        return finalPrice(a.price, a.discount_percent) - finalPrice(b.price, b.discount_percent);
      if (sort === "priceHigh")
        return finalPrice(b.price, b.discount_percent) - finalPrice(a.price, a.discount_percent);
      if (sort === "topRated") return (ratings[b.id]?.avg ?? 0) - (ratings[a.id]?.avg ?? 0);
      return b.created_at.localeCompare(a.created_at);
    });
    return list;
  }, [products, categories, q, category, maxPrice, minRating, inStockOnly, featuredOnly, sort, ratings]);

  function clear() {
    setQ("");
    setCategory("all");
    setMaxPrice(30000);
    setMinRating(0);
    setInStockOnly(false);
    setFeaturedOnly(false);
  }

  return (
    <StoreLayout>
      <div className="container-page py-8">
        <h1 className="mb-6 text-4xl">{t("shop")}</h1>

        <div className="mb-4 flex flex-wrap items-center gap-3">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("searchPlaceholder")}
            maxLength={80}
            className="max-w-sm"
          />
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="w-44">
              <SelectValue placeholder={t("sort")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">{t("newest")}</SelectItem>
              <SelectItem value="priceLow">{t("priceLow")}</SelectItem>
              <SelectItem value="priceHigh">{t("priceHigh")}</SelectItem>
              <SelectItem value="topRated">{t("topRated")}</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="secondary"
            onClick={() => setShowFilters((v) => !v)}
            className="lg:hidden"
          >
            <SlidersHorizontal className="size-4" /> {t("filters")}
          </Button>
        </div>

        <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
          <aside className={`${showFilters ? "block" : "hidden"} space-y-6 lg:block`}>
            <div className="card-surface space-y-5 p-5">
              <div className="space-y-2">
                <Label>{t("categories")}</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("allCategories")}</SelectItem>
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.slug}>
                        {pick(c, "name")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <Label>
                  {t("price")}: ≤ {formatDZD(maxPrice, lang)}
                </Label>
                <Slider
                  value={[maxPrice]}
                  min={1000}
                  max={30000}
                  step={500}
                  onValueChange={(v) => setMaxPrice(v[0] ?? 30000)}
                />
              </div>

              <div className="space-y-2">
                <Label>{t("rating")}</Label>
                <div className="flex flex-col gap-1.5">
                  {[0, 3, 4, 5].map((r) => (
                    <button
                      key={r}
                      onClick={() => setMinRating(r)}
                      className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm ${
                        minRating === r ? "bg-primary/15 text-primary" : "hover:bg-surface-2"
                      }`}
                    >
                      {r === 0 ? t("allCategories") : <Stars value={r} />}
                      {r > 0 && <span>+</span>}
                    </button>
                  ))}
                </div>
              </div>

              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={inStockOnly}
                  onCheckedChange={(v) => setInStockOnly(v === true)}
                />
                {t("inStock")}
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={featuredOnly}
                  onCheckedChange={(v) => setFeaturedOnly(v === true)}
                />
                {t("featured")}
              </label>

              <Button variant="ghost" onClick={clear} className="w-full">
                {t("clearFilters")}
              </Button>
            </div>
          </aside>

          <div>
            {isLoading ? (
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="aspect-[3/4] animate-pulse rounded-2xl bg-surface" />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <p className="py-16 text-center text-muted-foreground">{t("noResults")}</p>
            ) : (
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                {filtered.map((p) => (
                  <ProductCard key={p.id} product={p} rating={ratings[p.id]} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </StoreLayout>
  );
}
