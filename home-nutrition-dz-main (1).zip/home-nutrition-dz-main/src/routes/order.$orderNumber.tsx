import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StoreLayout } from "@/components/StoreLayout";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { useSettings } from "@/lib/settings";

export const Route = createFileRoute("/order/$orderNumber")({
  head: () => ({
    meta: [
      { title: "Order Confirmed — Home Nutrition Algeria" },
      { name: "description", content: "Your supplement order is confirmed. Keep your order number to track your delivery anywhere in Algeria." },
      { property: "og:title", content: "Order Confirmed — Home Nutrition" },
      { property: "og:description", content: "Thanks for your order. We'll call you to confirm the delivery." },
    ],
  }),
  component: OrderConfirmation,
});

function OrderConfirmation() {
  const { orderNumber } = Route.useParams();
  const settings = useSettings();
  return (
    <StoreLayout>
      <div className="container-page max-w-xl py-16 text-center">
        <CheckCircle2 className="mx-auto size-14 text-primary" />
        <h1 className="mt-5 text-4xl">Order confirmed</h1>
        <p className="mt-3 text-muted-foreground">
          Your order number is <span className="font-display text-2xl text-primary">{orderNumber}</span>.
          We'll call you shortly to confirm the delivery.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <Button asChild className="rounded-full">
            <Link to="/track">Track order</Link>
          </Button>
          <Button asChild variant="secondary" className="rounded-full">
            <Link to="/shop">Continue shopping</Link>
          </Button>
          <WhatsAppButton
            label="Confirm on WhatsApp"
            message={`🛒 ${settings.store_name} — Commande ${orderNumber}. Bonjour, je souhaite confirmer ma commande.`}
          />
        </div>
      </div>
    </StoreLayout>
  );
}
