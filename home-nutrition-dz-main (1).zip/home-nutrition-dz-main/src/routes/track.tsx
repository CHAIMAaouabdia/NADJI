import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { StoreLayout } from "@/components/StoreLayout";
import { trackOrder } from "@/lib/orders.functions";
import { formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/track")({
  head: () => ({
    meta: [
      { title: "Track Your Order — Home Nutrition Algeria" },
      { name: "description", content: "Enter your order number and phone number to see the current status of your supplement delivery in Algeria." },
      { property: "og:title", content: "Track Your Order — Home Nutrition" },
      { property: "og:description", content: "Follow your supplement order from confirmation to delivery." },
    ],
  }),
  component: Track,
});

type Result = Awaited<ReturnType<typeof trackOrder>>;

function Track() {
  const track = useServerFn(trackOrder);
  const { lang } = useI18n();
  const navigate = useNavigate();
  const [orderNumber, setOrderNumber] = useState("");
  const [phone, setPhone] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await track({ data: { order_number: orderNumber.trim(), phone: phone.trim() } });
      setResult(res);
      if (!res.found) toast.error("No order found with those details");
    } catch {
      toast.error("Could not track that order");
    } finally {
      setBusy(false);
    }
  }

  return (
    <StoreLayout>
      <div className="container-page max-w-xl py-10">
        <h1 className="mb-6 text-4xl">Track order</h1>
        <form onSubmit={submit} className="card-surface space-y-4 p-5">
          <div className="space-y-1.5">
            <Label htmlFor="on">Order number</Label>
            <Input id="on" value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} maxLength={40} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ph">Phone number</Label>
            <Input id="ph" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={20} required />
          </div>
          <Button type="submit" disabled={busy} className="w-full rounded-full">
            {busy ? "Searching…" : "Track"}
          </Button>
        </form>

        {result?.found && (
          <div className="card-surface mt-6 space-y-3 p-5">
            <div className="flex items-center justify-between">
              <span className="font-display text-2xl">{result.order.order_number}</span>
              <span className="rounded-full bg-primary/15 px-3 py-1 text-sm font-semibold text-primary">
                {result.order.status}
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              {result.order.full_name} · {result.order.commune}, {result.order.wilaya} ·{" "}
              {result.order.delivery_method === "home" ? "Home delivery" : "Desk delivery"}
            </p>
            <ul className="space-y-1 text-sm">
              {result.items.map((i, idx) => (
                <li key={idx} className="flex justify-between">
                  <span className="text-muted-foreground">
                    {i.item_name} × {i.quantity}
                  </span>
                  <span>{formatDZD(i.line_total, lang)}</span>
                </li>
              ))}
            </ul>
            <div className="border-t border-border pt-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery</span>
                <span>{formatDZD(result.order.delivery_fee, lang)}</span>
              </div>
              <div className="flex justify-between font-display text-xl text-primary">
                <span>Total</span>
                <span>{formatDZD(result.order.total, lang)}</span>
              </div>
            </div>
            <Button variant="secondary" className="w-full" onClick={() => navigate({ to: "/shop" })}>
              Continue shopping
            </Button>
          </div>
        )}
      </div>
    </StoreLayout>
  );
}
