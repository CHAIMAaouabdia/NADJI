import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StoreLayout } from "@/components/StoreLayout";
import { useCart } from "@/lib/cart";
import { formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart — Home Nutrition Algeria" },
      { name: "description", content: "Review your supplement cart, adjust quantities and continue to checkout with delivery anywhere in Algeria." },
      { property: "og:title", content: "Your Cart — Home Nutrition" },
      { property: "og:description", content: "Review your supplements and checkout with cash on delivery in Algeria." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const cart = useCart();
  const { lang, pick } = useI18n();

  return (
    <StoreLayout>
      <div className="container-page py-8">
        <h1 className="mb-6 text-4xl">Cart</h1>
        {cart.items.length === 0 ? (
          <div className="card-surface p-10 text-center">
            <p className="text-muted-foreground">Your cart is empty.</p>
            <Button asChild className="mt-5 rounded-full">
              <Link to="/shop">Shop now</Link>
            </Button>
          </div>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
            <ul className="space-y-3">
              {cart.items.map((i) => (
                <li key={i.key} className="card-surface flex gap-4 p-3">
                  <img
                    src={i.image ?? "/images/product-whey.jpg"}
                    alt={pick(i, "name")}
                    loading="lazy"
                    width={200}
                    height={200}
                    className="size-24 rounded-xl object-cover"
                  />
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-semibold">{pick(i, "name")}</span>
                      <button onClick={() => cart.remove(i.key)} aria-label="Remove">
                        <Trash2 className="size-4 text-muted-foreground hover:text-destructive" />
                      </button>
                    </div>
                    <span className="text-sm text-muted-foreground">{formatDZD(i.price, lang)}</span>
                    <div className="mt-auto flex items-center gap-2">
                      <Button size="icon" variant="secondary" onClick={() => cart.setQuantity(i.key, i.quantity - 1)}>
                        <Minus className="size-4" />
                      </Button>
                      <span className="w-8 text-center font-semibold">{i.quantity}</span>
                      <Button
                        size="icon"
                        variant="secondary"
                        disabled={i.quantity >= i.maxStock}
                        onClick={() => cart.setQuantity(i.key, i.quantity + 1)}
                      >
                        <Plus className="size-4" />
                      </Button>
                      <span className="ms-auto font-display text-lg">
                        {formatDZD(i.price * i.quantity, lang)}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <aside className="card-surface h-fit space-y-3 p-5">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-semibold">{formatDZD(cart.subtotal, lang)}</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Delivery fee is calculated at checkout based on your wilaya.
              </p>
              <Button asChild size="lg" className="w-full rounded-full">
                <Link to="/checkout">Checkout</Link>
              </Button>
            </aside>
          </div>
        )}
      </div>
    </StoreLayout>
  );
}
