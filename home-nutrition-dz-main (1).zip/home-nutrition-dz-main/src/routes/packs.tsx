import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { StoreLayout } from "@/components/StoreLayout";
import { packsQuery } from "@/lib/queries";
import { formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/packs")({
  head: () => ({
    meta: [
      { title: "Supplement Packs & Bundles — Home Nutrition Algeria" },
      { name: "description", content: "Save with curated supplement bundles: mass gain, strength and starter packs delivered across Algeria." },
      { property: "og:title", content: "Supplement Packs — Home Nutrition" },
      { property: "og:description", content: "Curated bundles at pack prices, delivered in Algeria." },
    ],
  }),
  component: Packs,
});

function Packs() {
  const { pick, lang } = useI18n();
  const { data: packs = [] } = useQuery(packsQuery);

  return (
    <StoreLayout>
      <div className="container-page py-8">
        <h1 className="mb-6 text-4xl">Packs</h1>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {packs.map((p) => (
            <Link
              key={p.id}
              to="/pack/$slug"
              params={{ slug: p.slug }}
              className="group card-surface overflow-hidden transition-colors hover:border-primary/40"
            >
              <img
                src={p.image_url ?? "/images/pack-mass.jpg"}
                alt={pick(p, "name")}
                loading="lazy"
                width={1024}
                height={1024}
                className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="space-y-1 p-4">
                <h2 className="text-xl">{pick(p, "name")}</h2>
                <p className="line-clamp-2 text-sm text-muted-foreground">{pick(p, "description")}</p>
                <p className="font-display text-2xl text-primary">{formatDZD(p.pack_price, lang)}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </StoreLayout>
  );
}
