import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { StoreLayout } from "@/components/StoreLayout";
import { useSession } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { formatDZD } from "@/lib/format";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "My Account & Orders — Home Nutrition Algeria" },
      { name: "description", content: "View your Home Nutrition supplement orders, statuses and delivery details in one place." },
      { property: "og:title", content: "My Account — Home Nutrition" },
      { property: "og:description", content: "Your supplement order history and delivery statuses." },
    ],
  }),
  component: Account,
});

type OrderRow = {
  id: string;
  order_number: string;
  status: string;
  total: number;
  created_at: string;
  wilaya: string;
};

function Account() {
  const { user, loading } = useSession();
  const { lang } = useI18n();

  const { data: orders = [] } = useQuery({
    queryKey: ["my-orders", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<OrderRow[]> => {
      const { data, error } = await supabase
        .from("orders")
        .select("id, order_number, status, total, created_at, wilaya")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as OrderRow[];
    },
  });

  return (
    <StoreLayout>
      <div className="container-page max-w-2xl py-10">
        <h1 className="mb-6 text-4xl">My account</h1>
        {loading ? null : !user ? (
          <div className="card-surface p-8 text-center">
            <p className="text-muted-foreground">Sign in to see your orders.</p>
            <Button asChild className="mt-5 rounded-full">
              <Link to="/auth">Sign in</Link>
            </Button>
          </div>
        ) : (
          <>
            <p className="mb-5 text-sm text-muted-foreground">{user.email}</p>
            {orders.length === 0 ? (
              <p className="text-muted-foreground">No orders yet.</p>
            ) : (
              <ul className="space-y-3">
                {orders.map((o) => (
                  <li key={o.id} className="card-surface flex items-center justify-between p-4">
                    <div>
                      <p className="font-display text-xl">{o.order_number}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(o.created_at).toLocaleDateString()} · {o.wilaya}
                      </p>
                    </div>
                    <div className="text-end">
                      <p className="font-semibold">{formatDZD(o.total, lang)}</p>
                      <span className="text-xs text-primary">{o.status}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </div>
    </StoreLayout>
  );
}
