import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Package, ShieldCheck, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StoreLayout } from "@/components/StoreLayout";
import { ProductCard } from "@/components/ProductCard";
import { CategoryCarousel } from "@/components/CategoryCarousel";
import { categoriesQuery, packsQuery, productsQuery, ratingsQuery } from "@/lib/queries";
import { useI18n } from "@/lib/i18n";
import { formatDZD } from "@/lib/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Home Nutrition — Premium Supplements Delivered in Algeria" },
      {
        name: "description",
        content:
          "Authentic whey protein, creatine, mass gainers and value packs. Cash on delivery to all 58 Algerian wilayas.",
      },
      { property: "og:title", content: "Home Nutrition — Premium Supplements in Algeria" },
      {
        property: "og:description",
        content: "Authentic supplements delivered across all 58 wilayas of Algeria.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { t, pick, lang } = useI18n();
  const { data: products = [] } = useQuery(productsQuery);
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: packs = [] } = useQuery(packsQuery);
  const { data: ratings = {} } = useQuery(ratingsQuery);

  const categoryCounts = products.reduce<Record<string, number>>((acc, p) => {
    if (p.category_id) acc[p.category_id] = (acc[p.category_id] ?? 0) + 1;
    return acc;
  }, {});

  const featured = products.filter((p) => p.featured).slice(0, 8);
  const newest = products.slice(0, 4);

  return (
    <StoreLayout>
      <section className="relative overflow-hidden border-b border-border">
        <img
          src="/images/hero.jpg"
          alt=""
          width={1920}
          height={1080}
          className="absolute inset-0 h-full w-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
        <div className="container-page relative py-20 md:py-32">
          <div className="max-w-xl animate-rise space-y-6">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary">
              {t("algeriaOnly")}
            </span>
            <h1 className="text-5xl leading-[0.95] md:text-7xl">
              {t("heroPhrase")}
              <span className="block text-gradient-accent">{t("brand")}</span>
            </h1>
            <p className="text-lg text-muted-foreground">{t("tagline")}</p>

            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg" className="rounded-full px-7">
                <Link to="/shop">
                  {t("shopNow")} <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="secondary" className="rounded-full px-7">
                <Link to="/packs">{t("packs")}</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-surface">
        <div className="container-page grid grid-cols-1 gap-4 py-6 sm:grid-cols-3">
          {[
            { icon: ShieldCheck, label: t("authentic") },
            { icon: Truck, label: t("deliveryInfo") },
            { icon: Package, label: t("cashOnDelivery") },
          ].map((f) => (
            <div key={f.label} className="flex items-center gap-3 text-sm font-medium">
              <f.icon className="size-5 text-primary" />
              {f.label}
            </div>
          ))}
        </div>
      </section>

      <section className="container-page py-12">
        <div className="mb-5 flex items-end justify-between gap-3">
          <div>
            <h2 className="text-3xl md:text-4xl">{t("categories")}</h2>
            <p className="text-sm text-muted-foreground">{t("swipeToExplore")}</p>
          </div>
          <Link to="/categories" className="text-sm font-semibold text-primary hover:underline">
            {t("viewAll")} →
          </Link>
        </div>
        <CategoryCarousel categories={categories} counts={categoryCounts} />
      </section>

      {featured.length > 0 && (
        <section className="container-page py-8">
          <SectionHead title={t("featured")} to="/shop" label={t("viewAll")} />
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} rating={ratings[p.id]} />
            ))}
          </div>
        </section>
      )}

      {packs.length > 0 && (
        <section className="container-page py-8">
          <SectionHead title={t("packs")} to="/packs" label={t("viewAll")} />
          <div className="grid gap-4 md:grid-cols-2">
            {packs.slice(0, 2).map((p) => (
              <Link
                key={p.id}
                to="/pack/$slug"
                params={{ slug: p.slug }}
                className="group card-surface flex items-center gap-4 overflow-hidden p-4 transition-colors hover:border-primary/40"
              >
                <img
                  src={p.image_url ?? "/images/pack-mass.jpg"}
                  alt={pick(p, "name")}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="size-28 shrink-0 rounded-xl object-cover"
                />
                <div>
                  <h3 className="text-xl">{pick(p, "name")}</h3>
                  <p className="line-clamp-2 text-sm text-muted-foreground">
                    {pick(p, "description")}
                  </p>
                  <p className="mt-2 font-display text-2xl text-primary">
                    {formatDZD(p.pack_price, lang)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section className="container-page py-8 pb-16">
        <SectionHead title={t("newest")} to="/shop" label={t("viewAll")} />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {newest.map((p) => (
            <ProductCard key={p.id} product={p} rating={ratings[p.id]} />
          ))}
        </div>
      </section>
    </StoreLayout>
  );
}

function SectionHead({ title, to, label }: { title: string; to: "/shop" | "/categories" | "/packs"; label: string }) {
  return (
    <div className="mb-5 flex items-end justify-between">
      <h2 className="text-3xl md:text-4xl">{title}</h2>
      <Link to={to} className="text-sm font-semibold text-primary hover:underline">
        {label} →
      </Link>
    </div>
  );
}
